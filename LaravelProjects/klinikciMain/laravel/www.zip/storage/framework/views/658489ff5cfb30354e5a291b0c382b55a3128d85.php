<!DOCTYPE HTML> <?php echo $__env->yieldContent('language'); ?>


<head>

    <?php echo $__env->yieldContent('title'); ?> 
    <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8"> <?php echo $__env->yieldContent('keywords'); ?>
    <meta name="_token" content="<?php echo csrf_token(); ?>" />

      <!-- js-->
      <script src="<?php echo e(asset('js/jquery-2.2.3.min.js')); ?>"></script>

    <!-- Bootstrap Core CSS -->
    <link href='https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css' rel='stylesheet' type='text/css' />
    <!-- font-awesome icons -->
    <link href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/style.css')); ?> " rel='stylesheet' type='text/css' />

    <!-- //Custom Theme files -->
    <!--webfonts-->
    <link href="//fonts.googleapis.com/css?family=Do+Hyeon" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- //webfonts -->

    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>

    <!-- header -->
    <?php echo $__env->make('components/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- //header -->
    <!-- banner -->

    <!-- buraya slider gelecek -->

    <!-- header sonu -->


    <?php echo $__env->yieldContent('icerik'); ?>





    </div>
    <!-- footer top -->
    <!-- footer -->
    <?php echo $__env->make('components/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- //footer -->
   
    <!-- subscribe form -->
    <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel2">Subscribe now!</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="#" method="post">
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Email</label>
                            <input type="email" class="form-control border" placeholder=" " name="email" id="usermail" required="">
                        </div>
                        <div class="right-w3l">
                            <input type="submit" class="form-control text-white" value="Subscribe">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- //subscribe form -->




  

    <!--  scriptler girildi      -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>





    <!-- //subscribe form -->
    <!-- js-->

    <!-- move-top -->
    <script src="<?php echo e(asset('js/move-top.js')); ?>"></script>
    <!-- easing -->

    <!--  yukarı butonuna basınca yavaşça çıkmasını sağlıyor      -->
    <script src="<?php echo e(asset('js/easing.js')); ?>"></script>
    <!-- smooth scroll -->


    <!-- scroolun yavaş kaymasını sağlıyor -->
    <script src="<?php echo e(asset('js/SmoothScroll.min.js')); ?>"></script>
    <!--  necessary snippets for few javascript files -->


    <script src="<?php echo e(asset('js/stock.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript -->

    <script>
        addEventListener("load", function () {
        setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
        window.scrollTo(0, 1);
    }
    </script>

    <?php echo $__env->yieldContent('js'); ?>

    <!--  scriptler girildi      -->


</body>

</html>