<!-- left grid -->
<div class="col-lg-3 ">
        <!-- Search Widget -->
       


        <!-- arama sonuçları -->
       
        <?php echo $__env->make('components.haberArama', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- arama sonucunda açılacak yer -->


        <!-- Categories Widget -->
        <div class="card my-4">
            <h5 class="card-header">Kategoriler</h5>
            <div class="card-body">
                <ul class="w3-tag2">

                    <?php $__currentLoopData = $haberKategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--     kategorilerd etekrar ettirilecekle burası       -->
                    <li>
                    <a href="/haber/<?php echo e(trim($kategori->url)); ?>">
                        <i class="fa fa-angle-right mr-2"></i><?php echo e(ilkHarfBuyuk($kategori->name)); ?></a>
                    </li>

                    <!--     kategorilerd etekrar ettirilecekle burası       -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </ul>
            </div>
        </div>
        <!-- Side Widget -->



        <!-- latest post -->
        <div class="card my-4 p-3 post_link">
            <h5 class="card-header">En son Haberler</h5>

            <?php $__currentLoopData = $enSonHaberler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             <!-- en son haberlerde tekrar ettirilecek yer          -->
             <div class="row mt-3">
                <div class="col-4">
                <a href="/haber/<?php echo e(trim($haber->kategori->url)); ?>/<?php echo e(trim($haber->url)); ?>">
                   
                        <img class="card-img-bottom" src="<?php echo e(asset('storage/assets').'/'.$haber->kapakResim->url); ?>" alt="<?php echo e($haber->kapakresim->aciklama); ?>">
                    
                    </a>
                </div>
                <div class="col-8 pl-0">
                <a href="/haber/<?php echo e(trim($haber->kategori->url)); ?>/<?php echo e(trim($haber->url)); ?>"><?php echo e(ilkHarfBuyuk($haber->baslik)); ?></a>
                    <p class="card-text">
                    <small class="text-muted"><?php echo e(getAgo($haber->eklenme_tarihi)); ?></small>
                    </p>
                </div>
            </div>

            <!-- en son haberlerde tekrar ettirilecek yer          -->
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           

        </div>
    </div>
    <!-- //left grid -->



    



   