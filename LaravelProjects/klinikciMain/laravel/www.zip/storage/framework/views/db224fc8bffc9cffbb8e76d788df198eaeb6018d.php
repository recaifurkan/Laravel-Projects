<?php $__currentLoopData = $yorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!--      yorum tekrar edilecek kısım         -->
<div class="media py-5">
    <img class="mr-3" src="<?php echo e(asset('storage/assets').'/'.$yorum->user->profilResim->url); ?>" alt="Generic placeholder image">
    <div class="media-body">
        <h5 class="mt-0"><?php echo e($yorum->user->name); ?></h5>
        <p><?php echo e($yorum->icerik); ?>

        </p>
        <p><?php echo e(getAgo($yorum->eklenme_tarih)); ?> </p>
        <a id="cevaplaButton" href=""><span><i class="fas fa-reply"></i>Cevapla</span></a>

        <!--  alt yorum için -->



        <?php if(!Auth::check()): ?>
        <div style="display: none;text-align: center;">
            <p>Cevap verebilmek için lütfen giriş yapınız...</p>

            <button type="button" class="btn btn-danger ml-lg-5 w3ls-btn" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">
    Giriş Yap
    </button>
        </div>


        <?php else: ?>
        <div style="display: none;">

            <form action="/spot" method="POST" class="f-color p-3">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <input type="hidden" name="ustYorum" value="<?php echo e($yorum->id); ?>">
                   
                   

                    <textarea placeholder="Yorumunuz" style="width: 100%" id="altYorumText" name="altYorumText"></textarea>

                </div>
                <button type="submit" value="altYorum" name="altYorum" class="mt-3 btn btn-danger btn-block">Yorumu gönder</button>
            </form>
        </div>
        <?php endif; ?>
    <?php echo $__env->make('spot-ham.altyorumlar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
</div>

<!--      yorum tekrar edilecek kısım         -->


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>