 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title>DusTus Live</title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="---------------" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>






<!-- //inner banner -->
<!-- breadcrumbs -->
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item active" aria-current="page">Single</li>
    </ol>
</nav>
<!-- //breadcrumbs -->
<!--  single page -->
<section class="single_blog_wthree py-3">
    <div class="container pt-lg-5">
        <div class="row py-sm-3">
            <!-- single page left grid -->
            <div class="col-lg-9  single-left">
                <div class="row show-top-grids">
                    <div class="card">
                        <h5 class="blog-title singlpage_w3 card-title font-weight-bold">
                            Transform Your Dreams Into Reality
                        </h5>
                        <img class="card-img-bottom" src="images/img4.jpg" alt="Card image cap">
                        <div class="card-body">
                            <div class="d-sm-flex justify-content-between border-bottom pb-3">
                                <div class="blog_w3icon">
                                    <span>
                                        <i class="fas fa-user mr-2"></i>Stella</span>
                                    <span class="ml-3">
                                        <i class="fab fa-servicestack mr-2"></i>Funding Trends</span>
                                </div>
                            </div>
                            <article class="mt-3">Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent
                                sapien massa, convallis a pellentesque nec, egestas non nisi. Vivamus suscipit tortor eget
                                felis porttitor volutpat</article>
                            <p class="card-text mt-3">Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vivamus suscipit tortor eget felis
                                porttitor volutpat. Proin eget tortor risus. Curabitur non nulla sit amet nisl tempus convallis
                                quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vivamus
                                suscipit tortor eget felis porttitor volutpat..
                            </p>
                        </div>
                        <div class="d-sm-flex">
                            <div class="col-md-6">
                                <p class="card-text mt-3 text-muted">Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vivamus suscipit tortor eget
                                    felis porttitor volutpat. Proin eget tortor risus. Curabitur non nulla sit amet nisl
                                    tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec,
                                    egestas non nisi. Vivamus suscipit tortor eget felis porttitor volutpat..
                                </p>
                            </div>
                            <div class="col-md-6 mt-sm-0 my-4">
                                <img src="images/g1.jpg" alt="" class="img-fluid" />
                            </div>
                        </div>
                        <div class="card-footer">
                            <p class="card-text">
                                <small class="text-muted">Last updated 3 mins ago</small>
                            </p>
                        </div>
                    </div>
                    <div class="all-comments mt-5">
                        <div class="wthree-form-left">
                            <!-- contact form grid -->
                            <div class="contact-top1">
                                <h5 class="text-dark mb-4 text-capitalize">leave a reply</h5>
                                <form action="#" method="get" class="f-color p-3">
                                    <div class="form-group">
                                        <label for="contactcomment">Your Comment</label>
                                        <textarea class="form-control border" rows="5" id="contactcomment" required=""></textarea>
                                    </div>
                                    <div class="d-sm-flex">
                                        <div class="col-sm-6 form-group p-0">
                                            <label for="contactusername">Name</label>
                                            <input type="text" class="form-control border" id="contactusername" required="">
                                        </div>
                                        <div class="col-sm-6 form-group ml-sm-3">
                                            <label for="contactemail">Email</label>
                                            <input type="email" class="form-control border" id="contactemail" required="">
                                        </div>
                                    </div>
                                    <button type="submit" class="mt-3 btn btn-danger btn-block">Post Comment</button>
                                </form>
                            </div>
                            <!--  //contact form grid ends here -->
                        </div>
                        <div class="media py-5">
                            <img class="mr-3" src="images/m.png" alt="Generic placeholder image">
                            <div class="media-body">
                                <h5 class="mt-0">Michael</h5>
                                <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin.
                                    Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
                                </p>
                                <div class="media mt-5">
                                    <a class="pr-3" href="#">
                                        <img src="images/f.png" alt="Generic placeholder image">
                                    </a>
                                    <div class="media-body">
                                        <h5 class="mt-0">James</h5>
                                        <p> Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin.
                                            Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum
                                            nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="media">
                            <img class="mr-3" src="images/m.png" alt="Generic placeholder image">
                            <div class="media-body">
                                <h5 class="mt-0">Jack</h5>
                                <p> Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin.
                                    Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //single page right grid -->
            <!-- side bar -->
            <div class="col-lg-3 sidebar_wthree">
                <!-- Search Widget -->
                <div class="card mb-4">
                    <h5 class="card-header">Search</h5>
                    <div class="card-body">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search for...">
                            <span class="input-group-btn">
                                <button class="btn btn-secondary" type="button">Go!</button>
                            </span>
                        </div>
                    </div>
                </div>
                <!-- Categories Widget -->
                <div class="card my-4">
                    <h5 class="card-header">Categories</h5>
                    <div class="card-body">
                        <ul class="w3-tag2">
                            <li>
                                <a href="single.html">
                                    <i class="fa fa-angle-right mr-2"></i>dictumamet</a>
                            </li>
                            <li>
                                <a href="single.html">
                                    <i class="fa fa-angle-right mr-2"></i>placerat</a>
                            </li>
                            <li>
                                <a href="single.html">
                                    <i class="fa fa-angle-right mr-2"></i>Proin </a>
                            </li>
                            <li>
                                <a href="single.html">
                                    <i class="fa fa-angle-right mr-2"></i>vehicula</a>
                            </li>
                            <li>
                                <a href="single.html">
                                    <i class="fa fa-angle-right mr-2"></i>Quisquevelit</a>
                            </li>
                            <li>
                                <a href="single.html">
                                    <i class="fa fa-angle-right mr-2"></i>felis</a>
                            </li>
                            <li>
                                <a href="single.html">
                                    <i class="fa fa-angle-right mr-2"></i>mauris</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Side Widget -->
                <div class="card my-4">
                    <h5 class="card-header">Text Widget</h5>
                    <div class="card-body">
                        <p> Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vivamus suscipit tortor eget felis
                            porttitor volutpat.
                        </p>
                    </div>
                </div>
                <!-- latest post -->
                <div class="card my-4 p-3 post_link">
                    <h5 class="card-header">Latest posts</h5>
                    <div class="row mt-3">
                        <div class="col-4">
                            <a href="blog.html">
                                <img class="card-img-bottom" src="images/img2.jpg" alt="Card image cap">
                            </a>
                        </div>
                        <div class="col-8 pl-0">
                            <a href="blog.html">eveniie arcet ut moles morbi dapiti</a>
                            <p class="card-text">
                                <small class="text-muted">26 April,2018</small>
                            </p>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-4">
                            <a href="blog.html">
                                <img class="card-img-bottom" src="images/img5.jpg" alt="Card image cap">
                            </a>
                        </div>
                        <div class="col-8 pl-0">
                            <a href="blog.html">eveniie arcet ut moles morbi dapiti</a>
                            <p class="card-text">
                                <small class="text-muted">1 May, 2018</small>
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <a href="blog.html">
                                <img class="card-img-bottom" src="images/img4.jpg" alt="Card image cap">
                            </a>
                        </div>
                        <div class="col-8 pl-0">
                            <a href="blog.html">eveniie arcet ut moles morbi dapiti</a>
                            <p class="card-text">
                                <small class="text-muted">10 May 2018</small>
                            </p>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-4">
                            <a href="blog.html">
                                <img class="card-img-bottom" src="images/img3.jpg" alt="Card image cap">
                            </a>
                        </div>
                        <div class="col-8 pl-0">
                            <a href="blog.html">eveniie arcet ut moles morbi dapiti</a>
                            <p class="card-text">
                                <small class="text-muted">12 May 2018</small>
                            </p>
                        </div>
                    </div>
                </div>
                <!-- //side bar -->

            </div>
        </div>
    </div>
</section>
<!-- //single blog -->
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>