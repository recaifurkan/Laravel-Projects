

<?php $__currentLoopData = $yorum->altYorumlar()->orderBy('eklenme_tarih','desc')->get();; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altYorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div style="margin-left: 50px;" class="media ">
    <a class="pr-3" href="#">
        <img class="yorumProfilImage"
        src="<?php echo e(route('profilResim',['uyeId'=>$altYorum->user->id])); ?>" 
        alt="<?php echo e(isset($altYorum->user->name) ? $altYorum->user->name: $altYorum->user->kullanici_adi); ?>">
    </a>
    <div class="media-body">
        <h5 class="mt-0"><?php echo e($altYorum->user->name); ?></h5>
        <p> <?php echo htmlspecialchars_decode($altYorum->icerik); ?></p>
        <p><?php echo e(getAgo($altYorum->eklenme_tarih)); ?> </p>
    </div>
</div>

<!--  alt yorum için                  -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>