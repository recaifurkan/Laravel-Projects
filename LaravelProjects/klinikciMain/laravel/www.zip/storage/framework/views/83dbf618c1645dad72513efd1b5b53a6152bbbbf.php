 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>



<div class="container" style="text-align: center">
    <section>
        <center>


            <div class="card mb-4">

                <div class="card-body">

                    <div class="input-group">
                        <input id="search-text" class="form-control" placeholder="Konularda Ara" type="text">
                        <span class="input-group-btn">
                            <button id="search" class="btn btn-secondary" type="submit">Ara</button>
                        </span>
                    </div>

                </div>
            </div>

            <!-- arama sonucunda açılacak -->
            <!-- latest post -->
            <div style="display: none;" id="search-result" class="row">
                <div class="card my-4 p-3 post_link col-md-12 ">
                    <h5 class=" card-header"><span id="aranan-kelime" class="badge badge-info"></span><span> için sonuçlar</span> </h5>


                    <!--     konunun limki buraya koyulacak        -->

                    <div class="row mt-3">

                        <div class="forum-home-parent col-12 pl-0">
                            <div class="forum-home col-md-12">
                                <a href="blog.html">eveniie arcet ut moles morbi dapiti </a>
                                <div>
                                    <span style="text-align: end" class="badge badge-secondary">26 April,2018</span>
                                    <span>
                                        <i class="far fa-comments"></i>25</span>
                                    <span>
                                        <i class="far fa-eye"></i>15</span>
                                    <span>
                                        <i class="far fa-thumbs-up"></i>20</span>


                                </div>
                            </div>
                        </div>
                        <div class="hr"></div>
                    </div>
                    <!--     konunun limki buraya koyulacak        -->

                </div>



            </div>

            <!-- arama sonucunda açılacak yer -->


            <!-- latest post -->
            <div class="row">
                <div class="card my-4 p-3 post_link col-md-12 ">
                    <h5 class="card-header">Bugün Tartışılan Konular</h5>


                    <!--     konunun limki buraya koyulacak        -->

                    <div class="row mt-3">

                        <div class="forum-home-parent col-12 pl-0">
                            <div class="forum-home col-md-12">
                                <a href="blog.html">eveniie arcet ut moles morbi dapiti </a>
                                <div>
                                    <span style="text-align: end" class="badge badge-secondary">26 April,2018</span>
                                    <span>
                                        <i class="far fa-comments"></i>25</span>
                                    <span>
                                        <i class="far fa-eye"></i>15</span>
                                    <span>
                                        <i class="far fa-thumbs-up"></i>20</span>


                                </div>
                            </div>
                        </div>
                        <div class="hr"></div>
                    </div>
                    <!--     konunun limki buraya koyulacak        -->

                </div>



            </div>

            <!-- farklı konudaki konuların gösterilmesi gereken yer -->






        </center>
    </section>
</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>



<!-- arama sonuçarı için açılacak div burası -->
<script>
    $(function(){
          
    $('#search-text').on('input',function(e){
        if($(this).val()==''){
            $('#search-result').slideUp();
        }
        else{
           
            $('#search-result').slideDown();
            $('#aranan-kelime').html($(this).val());
        }
       
        



});



});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>