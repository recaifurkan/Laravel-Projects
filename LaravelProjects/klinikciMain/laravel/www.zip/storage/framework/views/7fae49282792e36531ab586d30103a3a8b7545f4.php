<?php $__env->startSection('css'); ?>
    <!-- DATA TABLES -->
    <link href="/admin/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Slaytlar
        
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <?php echo $__env->make('admin/showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>İd</th>
                    <th>İcerik</th>
                    <th>Beğeni</th>
                    <th>Mesaj onay</th>
                    <th>Yazılma Tarihi</th>
                    <th>Konu id</th>
                    <th>Konusu</th>
                    <th>İşlemler</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $mesajlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesaj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
               
                  <tr>
                      <td><?php echo e($mesaj->id); ?></td>
                      <td><?php echo htmlspecialchars_decode($mesaj->icerik); ?></td>
                      <td><?php echo e($mesaj->begeni); ?></td>
                      <td><?php echo e($mesaj->mesaj_onay); ?></td>
                      <td><?php echo e($mesaj->yazilma_tarihi); ?></td>
                    <?php if(isset($mesaj->konu)): ?>
                    <td><?php echo e($mesaj->konu->id); ?></td>
                    <?php else: ?>
                    <td></td>    
                    <?php endif; ?>
                    <td><?php echo e($mesaj->user->name); ?></td>
                    <td>
                      <form action="/admin/forum/deleteMessage" method="POST">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="mesajId" value="<?php echo e($mesaj->id); ?>">
                      <input type="submit" class="btn btn-danger" name="delete" value="Sil">
                    
                    </form>
                    </td>
                   
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tfoot>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>