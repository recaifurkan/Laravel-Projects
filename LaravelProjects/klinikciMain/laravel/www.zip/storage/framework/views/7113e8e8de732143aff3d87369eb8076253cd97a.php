 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>







<!--  başlık belirtilecek  -->



<?php $__env->startSection('title'); ?>
<title>Usiyer</title>
<?php $__env->stopSection(); ?>




<!-- keywordlar belirtilecek -->



<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="---------------" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>
<div class="container pt-3">
    <!-- slider sectionu tanımlandı -->
    <section class="slider">

        <script src="js/slider.js"></script>
        <link href="css/slider.css" rel='stylesheet' type='text/css' />


        <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:380px;overflow:hidden;visibility:hidden;">
           
            <div class="slider_sol" data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:380px;overflow:hidden;">

                <!-- slayt tekrar ettirilecek     -->

                <?php $__currentLoopData = $sliderler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slayt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                   
                    <img data-u="image"  src="<?php echo e(asset('storage/assets').'/'.$slayt->resim->url); ?>" />
                   
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </div>
            
            <!-- Bullet Navigator -->
            <div data-u="navigator" class="jssorb111" style="position:absolute;bottom:12px;right:12px;" data-scale="0.5">
                <div data-u="prototype" class="i" style="width:24px;height:24px;font-size:12px;line-height:24px;">
                    <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;z-index:-1;">
                    <circle class="b" cx="8000" cy="8000" r="3000"></circle>
                </svg>
                    <div data-u="numbertemplate" class="n"></div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            jssor_1_slider_init();
        </script>
        <!-- #endregion Jssor Slider End -->



    </section>





    <div class="row py-sm-5">
        <!-- left grid -->
        <div class="col-lg-8 sidebar_wthree">

            <!--   buraya içerikleri yerleştirecen        -->

            <!-- kategoriler bunlarla gösterilecek -->


            <!-- slider sectionu tanımlandı -->


            <!-- //banner bottom -->
            <!-- about -->
            <section class="py-3">
                <!-- blog -->
                <div class="container">
                    <div style="display:inline;">
                        <span style=" width:30%;">Haberler </span>
                        <div style=" display:inline-block;width:70%;background-color:#DBDBDB; border:solid 3px;border-radius:60px;border-color:#DBDBDB;">
                        </div>
                    </div>

                    <div class="row">

                        <!-- haber tekrar edilecek burada -->
                      
                        <?php echo $__env->make('components.haberler',['haberler'=>$haberler], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                 
                                 

                      



                    </div>
                    <div style="margin-top: 10px" class="alert alert-success text-center" role="alert">
                            <a href="/haber">Haberlere Bak</a>
                          </div>
                </div>

            </section>
            <!-- //about -->







        </div>


        <!-- //left gfrid -->
        <!-- right grid -->
        <div class="col-lg-4">
            
            
            
            <?php echo $__env->make('components.spot-bilgiler', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
        <!-- //blog grid -->
    </div>
    <!-- //right grid -->
</div>
</div>
<!-- //blog -->



<section>
    <div class="container py-sm-5">



        <section>
            <!-- latest post -->
            <div class="row">
                <div class="card my-4 p-3 post_link col-md-6">
                    <h5 class="card-header">En Son Açılan Konular</h5>
                   
                   
                   <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $enSonAcilanKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   
                </div>

                <!-- latest post -->
                <div class="card my-4 p-3 post_link col-md-6">
                    <h5 class="card-header">En Beğenilen Konular</h5>
                    
                    
                    <?php echo $__env->make('components.anasayfaForumKonular',['konular'=>$enCokBegenilenKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    
                   
                    


                </div>

            </div>

        </section>

        <!-- daha iyisini bulana kadar en iyi timer bu   -->
        <div class="soon_banner layer">
            <div class="soon-content-agile">
                <div class="w3l-agile text-center">
                    <h4>En Yakın Tusa Kalan</h4>
                </div>

                <!--timer-->
                <div class="examples my-5">
                    <div class="simply-countdown-losange" id="simply-countdown-losange"></div>
                </div>
                <!--//timer-->

            </div>
            <!-- //content -->


        </div>

        <div class="soon_banner layer">
                <div class="soon-content-agile">
                    <div class="w3l-agile text-center">
                        <h4>En Yakın Dusa Kalan</h4>
                    </div>
    
                    <!--timer-->
                    <div class="examples my-5">
                            <div class="simply-countdown-losange" id="simply-countdown-losange2"></div>
                        </div>
                    <!--//timer-->
    
                </div>
                <!-- //content -->
    
    
            </div>



</section>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>






<?php if(Auth::check()): ?>
                                     
                                        <script>
                                                // burada beğeni tuşu ayarlaması yapıldı
                                                            $(function(){
                                            
                                                        $('.konuBegen').click(function(e){
                                                            e.preventDefault();
                                                            var form = $(this).next();
                                                            
                                                            // console.log(form);
                                                            
                                            
                                                        $.ajax({
                                                        type: "POST",
                                                        url: form.attr('action'),
                                                        data: form.serialize() ,
                                                        success: function (data){
                                                            
                                                            // console.log(data);
                                                            location.reload();
                                                        },
                                            
                                                        });
                                            
                                            
                                                        });
                                            
                                            
                                                        });
                                            
                                            // burada beğeni tuşu ayarlaması yapıldı
                                                </script>

                                                <?php endif; ?>


<!-- Countdown-Timer-JavaScript -->
<script src="<?php echo e(asset('js/simplyCountdown.js')); ?>"></script>

<?php
    
$tus =    $sinavlar->where('sinav_tur','Tus')->first();
$dus =    $sinavlar->where('sinav_tur','Dus')->first();

// tus zamanlayısının hesapmaları
$timestampTus = strtotime($tus->sinav_tarih);

$dayTus = date('d', $timestampTus);

$monthTus = date('m', $timestampTus);

$YearTus = date('Y', $timestampTus);


// dus zamanlayıcısını hesaplamalrı
$timestampDus = strtotime($dus->sinav_tarih);

$dayDus = date('d', $timestampDus);

$monthDus = date('m', $timestampDus);

$YearDus = date('Y', $timestampDus);


?>

<!-- geriye sayan sayacımızı buradan ayarlayacaz -->
<!-- easy to customize -->
<script>
    $('#simply-countdown-losange').simplyCountdown({
            year: <?php echo e($YearTus); ?>,
            month: <?php echo e($monthTus); ?>,
            day: <?php echo e($dayTus); ?>

        });

        $('#simply-countdown-losange2').simplyCountdown({
            year: <?php echo e($YearDus); ?>,
            month: <?php echo e($monthDus); ?>,
            day: <?php echo e($dayDus); ?>

        });

         
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>