<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Slaytlar
        
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>İd</th>
                    <th>İçerik</th>
                    <th>Url</th>
                    <th>Anahtar Kelimeler</th>
                    <th>Beğeni Sayısı</th>
                    <th>Eklenme Tarihi</th>
                    <th>Hit</th>
                    <th>Ünitesi</th>
                    <th>Yazar</th>
                    <th>işlemler</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $spotlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($spot->id); ?></td>
                      <td><?php echo e($spot->icerik); ?></td>
                      <td><?php echo e($spot->url); ?></td>
                      <td><?php echo e($spot->keywords); ?></td>
                      <td><?php echo e($spot->like); ?></td>
                      <td><?php echo e($spot->eklenme_tarihi); ?></td>
                      <td><?php echo e($spot->hit); ?></td>
                      <td><?php echo e($spot->unite->name); ?></td>
                      <td><?php echo e($spot->user->name); ?></td>
                    <td><a href="">Düzenle</a><a href="">Sil</a></td>
                   
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                 
                </tfoot>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>