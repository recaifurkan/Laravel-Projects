<!-- latest post -->
<div class="card my-4 p-3 post_link">
        <h5 class="card-header" style="text-align: center">Spot Bilgiler
            <span class="spot_ders "><?php echo e($spotDers->name); ?></span>
        </h5>
       
       
        <div class="spot-anasayfa  mt-3" style="text-align: center">
           
            <?php $__currentLoopData = $uniteSpotlari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="spot-pano col-12">
                    <div>
                        <a style="line-height: 40px;" href="/spot/<?php echo e($spotDers->kategori->url); ?>/<?php echo e($spotDers->url); ?>/<?php echo e($spot->unite->url); ?>/<?php echo e($spot->url); ?>">
                            <h5><?php echo e(strlen($spot->icerik)>25?substr($spot->icerik,0,25).'...':$spot->icerik); ?></h5>
                                                                                            </a>
                                <div class="text-white text-center spot-bilgi">



                                        <div   >
                                               
                                         <span class="badge badge-pill badge-info"> <i style="color:black;" class="far fa-eye"></i><?php echo e($spot->hit); ?></span>
                                       
                                        <span class="badge badge-pill badge-danger">  <i style="" class="far fa-thumbs-up"></i><?php echo e($spot->like); ?></span>
                                        
                                        <?php if(Auth::check()&& !userLikeSpot($spot)): ?>
                                        <a href="" class="spotBegen" style="height: 25px;line-height: 19px;"   class="badge"> <i class="far fa-thumbs-up"></i>Beğen</a>
                                                <form class="spotBegen" style="display: none;" action='/spotBegen' method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="spotId" value="<?php echo e($spot->id); ?>">
                                                
                                                </form>
        
                                                <?php endif; ?>
                                                
        
        
                                    </div>
                                    <div >
                                        
                                    </div>
                        
                                
                        
                            </div>                                                   
                
                    </div>
                    <div class="hr"></div>
                    
                    <p class="card-text">
                        <small class="text-muted"></small>
                    </p>
                
                </div>


       
       
        
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

               

            
        </div>



    </div>
    <script>
    // burada beğeni tuşu ayarlaması yapıldı
                $(function(){

            $('.spotBegen').click(function(e){
                e.preventDefault();
                var form = $(this).next();
                
                // console.log(form);
                

            $.ajax({
            type: "POST",
            url: form.attr('action'),
            data: form.serialize() ,
            success: function (data){
                
                // console.log(data);
                location.reload();
            },

            });


            });


            });

// burada beğeni tuşu ayarlaması yapıldı
    </script>
