 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<title>Forum : Usiyer</title>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>

<div class="container">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                   
                   
                    <li class="breadcrumb-item active " aria-current="page">
                   Forum
                                </li>
                   
                   
                    
                      
                   
                </ol>
            </nav>
            <!-- //breadcrumbs -->
        </div>





<?php echo $__env->make('components.forumKonuEkle',['selectKategoriler'=>$selectKategoriler], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    
    



    




<div class="container" style="text-align: center">
    <?php echo $__env->make('components.forumKonuArama', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
   
    <section>
        
      

       <!-- arama sonucunda açılacak yer -->

       <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if($kategori->konular->count()>0): ?>
       <!-- latest post -->
       <div class="row">
          <div class="card my-4 p-3 post_link col-md-12 ">
          <a href="forum/<?php echo e($kategori->url); ?>"><h5 class="card-header"><?php echo e($kategori->name); ?></h5></a>


              <!--     konunun limki buraya koyulacak        -->

            
             
              <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $konular = $kategori->konular()->orderBy('acilis_tarihi','DESC')->paginate(15,['*'],$kategori->url)], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <div style="margin: auto;margin-top: 10px"><?php echo e($konular->links()); ?></div> 
             
             
              
            
             
             
              <!--     konunun limki buraya koyulacak        -->

          </div>

         

      </div>
      <?php endif; ?>

      <!-- farklı konudaki konuların gösterilmesi gereken yer -->
          
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



       <!-- latest post -->
       <div class="row">
           <div class="card my-4 p-3 post_link col-md-12 ">
               <h5 class="card-header">En Son Tartışılan Konular</h5>


               <!--     konunun limki buraya koyulacak        -->

              
              
               <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $enSonAcilanKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              
              
              
              
               <!--     konunun limki buraya koyulacak        -->

           </div>



       </div>

       <!-- farklı konudaki konuların gösterilmesi gereken yer -->

        <!-- latest post -->
        <div class="row">
           <div class="card my-4 p-3 post_link col-md-12 ">
               <h5 class="card-header">En Hit Alan Konular</h5>


               <!--     konunun limki buraya koyulacak        -->

              
              
               <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $enHitAlanKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              
              
              
              
               <!--     konunun limki buraya koyulacak        -->

           </div>



       </div>

       <!-- farklı konudaki konuların gösterilmesi gereken yer -->

        <!-- farklı konudaki konuların gösterilmesi gereken yer -->

        <!-- latest post -->
        <div class="row">
           <div class="card my-4 p-3 post_link col-md-12 ">
               <h5 class="card-header">En Çok Beğeni Alan Konular</h5>


               <!--     konunun limki buraya koyulacak        -->

              
              
               <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $enBegeniAlanKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              
              
              
              
               <!--     konunun limki buraya koyulacak        -->

           </div>



       </div>

       <!-- farklı konudaki konuların gösterilmesi gereken yer -->

     






       
            


       
    </section>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>


<?php if(Auth::check()): ?>
                                     
                                        <script>
                                                // burada beğeni tuşu ayarlaması yapıldı
                                                            $(function(){
                                            
                                                        $('.konuBegen').click(function(e){
                                                            e.preventDefault();
                                                            var form = $(this).next();
                                                            
                                                            // console.log(form);
                                                            
                                            
                                                        $.ajax({
                                                        type: "POST",
                                                        url: form.attr('action'),
                                                        data: form.serialize() ,
                                                        success: function (data){
                                                            
                                                            // console.log(data);
                                                            location.reload();
                                                        },
                                            
                                                        });
                                            
                                            
                                                        });
                                            
                                            
                                                        });
                                            
                                            // burada beğeni tuşu ayarlaması yapıldı
                                                </script>

                                                <?php endif; ?>







<?php $__env->stopSection(); ?>





<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>