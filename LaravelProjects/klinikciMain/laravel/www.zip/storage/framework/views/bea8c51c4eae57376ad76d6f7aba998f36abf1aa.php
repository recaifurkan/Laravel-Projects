<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Slaytlar
        
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                 
                  <tr>
                    <th>İd</th>
                    <th>Kullanıcı Adı</th>
                    <th>İsim</th>
                    <th>Soyisim</th>
                    <th>Üye e-mail</th>
                   
                   
                    <th>Banlandı</th>
                    <th>Üyelik Seviyesi</th>
                    <th>Sınav Türü</th>
                   
                    <th>İşlemler</th>
                   
                   
                   
                   
                    
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $uyeler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uye): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                  

                  
                  <tr>
                      <form action="/admin/editUye" method="post">
                        <?php echo csrf_field(); ?>
                  <td><input type="hidden" name="uyeId" value="<?php echo e($uye ->id); ?>"> </td>
                  <td><?php echo e($uye ->kullanici_adi); ?></td>
                  <td><?php echo e($uye->name); ?></td>
                  <td><?php echo e($uye->soyad); ?></td>
                  <td><?php echo e($uye->email); ?></td>
                  <td>
                    <select name="banlandi" >
                      <option <?php echo e($uye->uye_isbanlandi == 0 ? 'selected':''); ?> value="0">Banlanmadı</option>
                      <option <?php echo e($uye->uye_isbanlandi == 1 ? 'selected':''); ?> value="1">Banlandı</option>
                    </select>
                  </td>
                  <td><select multiple name="uyeRoller[]">
                    <?php
                        $uyeRoller = [];
                        foreach ($uye->roller as $rol ) {
                          array_push($uyeRoller,$rol->id);
                        }
                    ?>
                    <?php $__currentLoopData = $roller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if(in_array($rol->id,$uyeRoller)): ?>
                   <option selected value="<?php echo e($rol->id); ?>"><?php echo e($rol->name); ?></option>  
                   <?php else: ?>
                   <option  value="<?php echo e($rol->id); ?>"><?php echo e($rol->name); ?></option>
                   <?php endif; ?>
                 
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                  </select>
                </td>
                  <td><?php echo e($uye->sinav->sinav_tur); ?></td>
                    <td>
                      <input class="btn btn-info" type="submit" name="editUye" value="Düzenle">
                   
                    
                    </td>
                  </form>
                  </tr>
               
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tbody>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <div style="margin: auto">
    <?php echo e($uyeler->links()); ?>

    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>