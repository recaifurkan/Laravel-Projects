<?php $__env->startSection('icerik'); ?>
<div style="margin: auto" class="text-center container col-md-7">
    <div class="box box-primary">
        <div class="box-header">
        <h3 class="box-title">Spot Ünite : <?php echo e($unite->name); ?></h3>
        </div><!-- /.box-header -->
        <!-- form start -->
        <form role="form" action="/admin/spot/editUnite" method="post" >
          <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($unite->id); ?>" name="uniteId">
          <div class="box-body">

              <?php
              if(session()->get('succes')){
               $succes = session()->get('succes');
              }
                  
              ?>
             
              <?php if(isset($succes)): ?>
             
              <div class="alert-success" >
                  <?php echo e($succes); ?>

               </div>
             
             
                <?php endif; ?>
             
            <div class="form-group">
              <label for="exampleInputEmail1">Ünite ismi</label>
              <input value="<?php echo e($unite->name); ?>" name="uniteIsim" type="text" class="form-control" placeholder="İsim Giriniz">
            </div>
            <div class="form-group">
                    <label for="exampleInputPassword1">Açıklama</label>
                  <input value="<?php echo e($unite->aiklama); ?>" name="uniteAciklama" type="text" class="form-control"  placeholder="Açıklama">
                  </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Url</label>
            <input value="<?php echo e($unite->url); ?>" name="uniteUrl" type="text" class="form-control"  placeholder="Url">
            </div>
           
          
          </div><!-- /.box-body -->
    
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div><!-- /.box -->

</div>






    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>