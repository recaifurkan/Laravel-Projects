<?php $__env->startSection('css'); ?>
    <!-- DATA TABLES -->
    <link href="/admin/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Slaytlar
        
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>İd</th>
                    <th>Başlık</th>
                    <th>İçerik</th>
                    <th>Anahtar Kelimeler</th>
                    <th>Eklenme Tarihi</th>
                    <th>Hit</th>
                    <th>Kısa Açıklama</th>
                    <th>url</th>
                    <th>Kategorisi</th>
                    <th>Yazar</th>
                    <th>İşlemler</th>
                    
                  </tr>
                </thead>
                <tbody>

                  <?php $__currentLoopData = $haberler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                 
                  <tr>
                    <td><?php echo e($haber->id); ?></td>
                    <td><?php echo e($haber->baslik); ?></td>
                    <td><?php echo e($haber->icerik); ?></td>
                    <td><?php echo e($haber->keywords); ?></td>
                    <td><?php echo e($haber->eklenme_tarihi); ?></td>
                    <td><?php echo e($haber->hit); ?></td>
                    <td><?php echo e($haber->kisa_aciklama); ?></td>
                    <td><?php echo e($haber->url); ?></td>
                    <td><?php echo e($haber->kategori->name); ?></td>
                    <td><?php echo e($haber->user->name); ?></th>
                    <td><a href="">Düzenle</a><a href="">Sil</a></td>
                   
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tfoot>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>