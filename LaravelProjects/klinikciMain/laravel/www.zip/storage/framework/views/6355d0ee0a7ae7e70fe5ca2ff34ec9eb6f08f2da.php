<?php $__env->startSection('css'); ?>

<style>
.showImage{
  width: 100px;
  height: 100px;
}
</style>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('icerik'); ?>
<div style="margin: auto" class="text-center container col-md-7">
    
        <!-- form start -->
       
        <?php
        $resim = $haber->kapakResim;
    ?>
    <?php if(isset($resim)): ?>
        
    
     <h1>kapak Resmi</h1>
    <div style="z-index: 999; float: left" class="col-md-12">
            <img class="showImage" src="<?php echo e($path = asset('storage/assets').'/'.$resim->url); ?>" alt="<?php echo e($resim->aciklama); ?>" alt="">
            <span class="copyClip"><?php echo e($path); ?></span>
             
        </div>
        <?php endif; ?>
       <hr>

         
            <?php $__currentLoopData = $haber->resimler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
            <div style="z-index: 999; float: left" class="col-md-12">
                <img class="showImage" src="<?php echo e($path = asset('storage/assets').'/'.$resim->url); ?>" alt="<?php echo e($resim->aciklama); ?>" alt="">
                 <span class="copyClip"><?php echo e($path); ?></span>
                 
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
           
       
            
    
        
        
        <div class="box box-primary">
          <div class="box-header">
          <h3 class="box-title">Haber Düzenle -> <?php echo e($haber->kategori->name); ?></h3>
          </div><!-- /.box-header -->
          <div>  
             
         
            
        </div>


        
        <hr>
        <form  action="/admin/haber/editHaber" method="POST"  enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
        <input type="hidden" name="haberId" value="<?php echo e((isset($haber->id))?$haber->id:''); ?>">
          <div class="box-body">

              
              <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
             
              <div class="form-group">
                    <label for="exampleInputPassword1">Başlık</label>
                  <input name="haberAciklama" value="<?php echo e($haber->baslik); ?>" type="text" class="form-control" >
                  </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Anahtar Kelimeler</label>
            <input name="haberKeywords" value="<?php echo e($haber->keywords); ?>" type="text" class="form-control" >
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Url </label>
                <input value="<?php echo e($haber->url); ?>" name="haberUrl" type="text" class="form-control"  placeholder="url">
              </div>

              <div class="form-group">
                  <label for="exampleInputPassword1">Kısa Açıklama </label>
                  <input value="<?php echo e($haber->kisa_aciklama); ?>" name="haberAciklamasi" type="text" class="form-control"  placeholder="Haber Açıklaması">
                </div>

             
                <div class="form-group">
                  <label for="exampleInputFile">Haberin Ana resmini giriniz</label>
                  <input  name="haberAnaResim" type="file" id="exampleInputFile">
                  <p class="help-block">Resim Seç</p>
                </div>
                

                  <div class="form-group">
                    <label for="exampleInputPassword1">Haber Detayı </label>
                  <textarea name="haberIcerik" class="ckeditor" ><?php echo e(htmlspecialchars_decode($haber->icerik)); ?></textarea>
                   
                  </div>
           
          
          </div><!-- /.box-body -->
    
          <div class="box-footer">
            <button type="submit" value="submit" name="haberIcerikSubmit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div><!-- /.box -->

</div>






    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="/admin/plugins/ckeditor/ckeditor.js"></script>


<script>
    $(function(){
     
      $('.copyClip').click(function(e) {
        var copyText=$(this);
            copyText.select();

  
          document.execCommand("copy");
          alert("Copied the text: " + copyText.value);
      });



    })
   function copy(){
    
    var copyText = document.getElementById("myInput");

    /* Select the text field */
    copyText.select();

    /* Copy the text inside the text field */
    document.execCommand("copy");
    
   }
   
   </script>




    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>