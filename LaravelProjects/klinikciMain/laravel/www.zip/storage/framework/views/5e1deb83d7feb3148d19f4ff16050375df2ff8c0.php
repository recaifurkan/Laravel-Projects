<?php $__currentLoopData = $konular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                   
                  <div class="row text-center ">
                   
                    <div class="col-md-6  ">
                       
                    <a href="/forum/<?php echo e($konu->kategori->url); ?>/<?php echo e($konu->url); ?>"><?php echo htmlspecialchars_decode(ilkHarfBuyuk($konu->name)); ?></a>
                
                    </div>
                    <div  class="forum-bilgi col-md-6 text-muted">
                      
                                <span class="col-sm-3" ><i class="fas fa-comments"><?php echo e($konu->mesajlar->count()); ?></i></span>
                           
                                <span class="card-text col-sm-3"><i class="far fa-eye"><?php echo e($konu->goruntulenme_sayisi); ?></i></span>
                                
                        

                                 <span class="col-xs-3"  >
                                            <?php if(Auth::check()&& !userLikeKonu($konu)): ?> 
                                            <a href="" class="badge badge-pill badge-danger col-md-2 konuBegen"><i style="color: white" class="far fa-thumbs-up"></i> <?php echo e($konu->begenilme_sayisi); ?></a>
                                           
                                           
                                            <form class="konuBegen" style="display: none;" action='/konuBegen' method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="konuId" value="<?php echo e($konu->id); ?>">
                                            
                                            </form>
                                            <?php else: ?>
        
                                            <a  class="badge badge-pill col-md-2 badge-info "><i style="color: red" class="far fa-thumbs-up"></i> <?php echo e($konu->begenilme_sayisi); ?></a>
        
        
                                            <?php endif; ?>
                                        </span> 
                                       
                                   
                               




                                  
                           
                          
                        </div>
                
                 
                 
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   