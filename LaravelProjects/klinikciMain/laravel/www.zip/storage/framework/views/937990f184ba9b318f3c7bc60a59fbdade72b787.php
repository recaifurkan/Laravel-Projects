 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title>DusTus Live</title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="---------------" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/smartphoto.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>


<div class="container pt-3">
    <div class="row py-sm-5">
        <!-- left grid -->
        <div class="col-lg-9">
            <div class="row">













                <!--    buraya spotun resmi gelecek mümkünse resim 500 olsun        -->




                <div class="masonry col-md-3 ">

                    <div class="brick">
                        <a href="http://via.placeholder.com/500x500" class="js-img-viwer" data-caption="spotun aynısı" data-id="raion">
                                    <img style="width: 100%" src="http://via.placeholder.com/350x350" />
                                </a>
                    </div>


                </div>














                <div class="inner_banner layer col-md-9" id="home">
                    <div class="container">
                        <div class="agileinfo-inner">
                            <div class="row justify-content-center">
                                <h3 style="padding-bottom: 10px;padding-top: 10px;" class="text-center text-white">
                                    spot bilgi yazısı burada yazacak
                                </h3>
                            </div>
                            <div class="row justify-content-center">

                                <div class="text-white justify-content-center spot-bilgi">
                                    <div>
                                        <a style="height: 25px;line-height: 19px;" href="#" class="badge badge-info">
                                            <i class="far fa-thumbs-up"></i>16 Ağustos 2018</a>
                                    </div>
                                    <div>
                                        <i class="far fa-eye"></i>
                                        <span class="badge badge-pill badge-danger">20</span>
                                    </div>

                                    <div>
                                        <i class="far fa-thumbs-up"></i>
                                        <span class="badge badge-pill badge-danger"> 15</span>
                                    </div>

                                    <div class="justify-content-center">
                                        <a style="height: 25px;line-height: 19px;" href="#" class="badge badge-danger">
                                            <i class="far fa-thumbs-up"></i>Beğen</a>
                                    </div>

                                </div>
                                <style>
                                </style>

                            </div>
                        </div>
                    </div>
                </div>



                <div class="container">
                    <div class="all-comments mt-5">
                        <div class="wthree-form-left">
                            <!-- contact form grid -->
                            <div class="contact-top1">


                                <div class="media py-5">
                                    <img class="mr-3" src='<?php echo e(asset(' images/m.png ')); ?>' alt="Generic placeholder image">
                                    <div class="media-body">
                                        <h5 class="mt-0">Michael</h5>
                                        <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin.
                                            Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
                                        </p>
                                        <p>3Dakika Önce </p>
                                        <div class="media mt-5">
                                            <a class="pr-3" href="#">
                                                <img src="<?php echo e(asset('images/f.png')); ?>" alt="Generic placeholder image">
                                            </a>
                                            <div class="media-body">
                                                <h5 class="mt-0">James</h5>
                                                <p> Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque
                                                    ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus
                                                    viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec
                                                    lacinia congue felis in faucibus.</p>
                                                <p>3Dakika Önce </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="media">
                                    <img class="mr-3" src="<?php echo e(asset('images/m.png')); ?>" alt="Generic placeholder image">
                                    <div class="media-body">
                                        <h5 class="mt-0">Jack</h5>
                                        <p> Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin.
                                            Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.
                                        </p>
                                    </div>
                                </div>

                                <h5 class="text-dark mb-4 text-capitalize">Bir yorum yap</h5>
                                <form action="#" method="get" class="f-color p-3">

                                    <div class="d-sm-flex">
                                        <div class="col-sm-6 form-group p-0">
                                            <label for="contactusername">İsim</label>
                                            <input class="form-control border" id="contactusername" required="" type="text">
                                        </div>
                                        <div class="col-sm-6 form-group ml-sm-3">
                                            <label for="contactemail">E-mail</label>
                                            <input class="form-control border" id="contactemail" required="" type="email">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="contactcomment">Yorumunuz</label>

                                        <textarea id="contactcomment" name="editor1"></textarea>

                                    </div>
                                    <button type="submit" class="mt-3 btn btn-danger btn-block">Yorumu gönder</button>
                                </form>








                            </div>
                            <!--  //contact form grid ends here -->
                        </div>

                    </div>
                </div>














            </div>
        </div>
        <!-- //left grid -->
        <!-- right grid -->
        <div class="col-lg-3 sidebar_wthree">
            <!-- Search Widget -->
            <div class="card mb-4">

                <div class="card-body">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Spot Ara">
                        <span class="input-group-btn">
                            <button class="btn btn-secondary" type="button">Go!</button>
                        </span>
                    </div>
                </div>
            </div>
            <!-- Categories Widget -->
            <div class="card my-4">
                <h5 class="card-header">Konular</h5>
                <div class="card-body">
                    <ul class="w3-tag2">
                        <li>


                            <!-- konuları buradan tekrar ettirirsin -->
                            <a href="single.html">
                                <i class="fa fa-angle-right mr-2"></i>dictumamet</a>


                        </li>

                    </ul>
                </div>
            </div>

            <!-- latest post -->
            <!-- latest post -->
            <div class="card my-4 p-3 post_link">
                <h5 class="card-header">Spot Bilgiler
                    <span class="spot_ders ">Farmakoloji</span>
                </h5>
                <div class="row mt-3">

                    <!-- spot bilgileri burada tekrar ettirecen -->

                    <div class="spot-pano col-12 pl-0">
                        <a href="blog.html">Montelukast önemli bir astım ilacıdır</a>
                        <p class="card-text">
                            <small class="text-muted">26 April,2018</small>
                        </p>
                    </div>
                    <div class="hr"> </div>

                    <!-- spot bilgileri burada tekrar ettirecen -->






                </div>



            </div>
        </div>
        <!-- //right grid -->
    </div>
</div>
<!-- //blog -->
</div>
<?php $__env->stopSection(); ?>


<!-- icerik section sonu -->



<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('js/smartphoto.js?v=1')); ?>"></script>
<script>
    document.addEventListener('DOMContentLoaded',function(){
		new SmartPhoto(".js-img-viwer",{
            resizeStyle:'fit'
        });
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>