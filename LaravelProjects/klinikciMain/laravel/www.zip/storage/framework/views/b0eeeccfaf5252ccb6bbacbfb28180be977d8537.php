 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title><?php echo e($konu->ders->name); ?>-<?php echo e($konu->name); ?></title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="---------------" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>

<div class="container">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/spot">Spot</a>
                    </li>
                    <li class="breadcrumb-item">
                    <a href="../../<?php echo e($konu->ders->kategori->url); ?>"><?php echo e($konu->ders->kategori->name); ?></a>
                        </li>
                        <li class="breadcrumb-item">
                                <a href="../<?php echo e($konu->ders->url); ?>"><?php echo e($konu->ders->name); ?></a>
                                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e($konu->name); ?>

                    </li>
                </ol>
            </nav>
            <!-- //breadcrumbs -->
        </div>





<!-- spotlar bu şekilde ayarlanacak yalnız döngüde dikkat et 3 kere de başa alsın -->
<!-- Services section -->
<section class=" " id="we_offer_agile">
    <div class="container py-md-5 py-3">

        <div style="width: auto;" class="services-bot-agile ">
            <div class="row mt-5">
                    <?php
                    $index=0;
                ?>
    
                <?php $__currentLoopData = $spotlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-sm-6">
                        <div class="card">
                            <div class="card-block
                           <?php if($index%3==0): ?>
                           block-1
                           <?php endif; ?> 
                           <?php if($index%3==1): ?>
                           
                           <?php endif; ?>
                           <?php if($index%3==2): ?>
                           block-6
                           <?php endif; ?>
                           
                            
                            
                            ">
                            <p class="card-text"><?php echo e(strlen($spot->icerik)>25?substr($spot->icerik,0,25).'...':$spot->icerik); ?></p>

                        <a href="<?php echo e($spot->unite->url); ?>/<?php echo e($spot->url); ?>" title="Spota Git" class="read-more">Spota Git
                                <i class="fa fa-angle-double-right ml-2"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <?php
                $index+=1;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
        <div style="margin-top: 20px;">

                <?php echo e($spotlar->links()); ?>


        </div>
    </div>
</section>
<!-- /Services section -->
<?php $__env->stopSection(); ?>


<!-- icerik section sonu -->



<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>