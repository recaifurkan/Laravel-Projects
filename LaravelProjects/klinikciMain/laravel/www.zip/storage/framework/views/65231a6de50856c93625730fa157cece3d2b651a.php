 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<title>
<?php if(isset($kategori)): ?>
<?php echo e(ilkHarfBuyuk($kategori->name)); ?> : Haberler
<?php else: ?>
Haberler
   
<?php endif; ?>
</title>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>
<div class="container">
        <?php if(isset($kategori)): ?>
    <!-- breadcrumbs -->
    <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="/haber">Haberler</a>
                </li>
              
                <li class="breadcrumb-item active " aria-current="page">
               <?php echo e(ilkHarfBuyuk($kategori->name)); ?>

                            </li>
               
            </ol>
        </nav>
        <?php else: ?>
        <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">
                       Haberler
                    </li>
                  
                   
                   
                </ol>
            </nav>
        <?php endif; ?>

        <!-- //breadcrumbs -->
    </div>



<div class="container">
    <div class="row py-sm-5">
       
        <?php echo $__env->make('components.haberlerSlider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- right grid -->
        <div class="col-lg-9">



            <!--    haber tekrar ettirilecek yer başlangıç          -->


            <?php $__currentLoopData = $haberler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- blog grid -->
            <div style="margin-bottom: 10px" class="card">
                <div class="row no-gutters">
                    <div class="col-md-8">
                        <div class="card-body">
                            <div class="d-sm-flex justify-content-between  border-bottom py-2">
                                <h5 class="blog-title card-title font-weight-bold">
                                    <a href="/haber/<?php echo e(trim($haber->kategori->url)); ?>/<?php echo e(trim($haber->url)); ?>"><?php echo e(ilkHarfBuyuk($haber->baslik)); ?></a>
                                </h5>
                                <div class="blog_w3icon">
                                    <span>
                                    <i class="fas fa-user mr-2"></i><?php echo e(ilkHarfBuyuk($haber->user->name)); ?></span>
                                    <span class="ml-sm-3 ml-2">
                                        <span class="card-text col-sm-3"><i class="far fa-eye"><?php echo e($haber->hit); ?></i></span>
                                </div> 
                            </div>
                        <p class="card-text mt-3"><?php echo e(ilkHarfBuyuk($haber->kisa_aciklama)); ?></p>
                            <a href="/haber/<?php echo e(trim($haber->kategori->url)); ?>/<?php echo e(trim($haber->url)); ?>" class="blog-btn text-dark">Habere git</a>
                            <p class="card-text">
                            <small class="text-muted"><?php echo e(getAgo($haber->eklenme_tarihi)); ?></small>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <a href="/haber/<?php echo e(trim($haber->kategori->url)); ?>/<?php echo e(trim($haber->url)); ?>">
                           
                    <img class="card-img-haber" src="<?php echo e(asset('storage/assets').'/'.$haber->kapakResim->url); ?>" alt="<?php echo e($haber->kapakResim->aciklama); ?>">
                        </a>
                    </div>
                </div>
            </div>
            <!-- //blog grid -->
            <hr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

            <!--    haber tekrar ettirilecek yer başlangıç          -->

        </div>
        <!-- //right grid -->
        <div style="margin: auto;margin-top: 10px"><?php echo e($haberler->links()); ?></div> 
    </div>

</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>