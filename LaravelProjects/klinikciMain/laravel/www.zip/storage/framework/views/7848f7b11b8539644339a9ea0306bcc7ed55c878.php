<?php $__env->startSection('css'); ?>
    <!-- DATA TABLES -->
    <link href="/admin/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="row">
            <div class="col-md-8">
                <h1>
                     Kategori Haberleri : <?php echo e($kategori->name); ?>

                    
                  </h1>
            </div>
            <div class="col-md-4">
            <h1><a class="btn btn-success align-middle" href="/admin/haber/addHaber/<?php echo e($kategori->id); ?>">Haber Ekle</a></h1>
              
            </div>
    
          </div>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                  
                    <th>Başlık</th>
                    
                    <th>Anahtar Kelimeler</th>
                    <th>Eklenme Tarihi</th>
                    <th>Hit</th>
                    <th>Kısa Açıklama</th>
                    <th>url</th>
                    <th>Kategorisi</th>
                    <th>Yazar</th>
                    <th>İşlemler</th>
                    
                  </tr>
                </thead>
                <tbody>

                  <?php $__currentLoopData = $haberler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                 
                  <tr>
                   
                    <td><?php echo e($haber->baslik); ?></td>
                   
                    <td><?php echo e($haber->keywords); ?></td>
                    <td><?php echo e($haber->eklenme_tarihi); ?></td>
                    <td><?php echo e($haber->hit); ?></td>
                    <td><?php echo e($haber->kisa_aciklama); ?></td>
                    <td><?php echo e($haber->url); ?></td>
                    <td><?php echo e($haber->kategori->name); ?></td>
                    <td><?php echo e($haber->user->name); ?></th>
                    <td><a class="btn btn-info" href="/admin/haber/editHaber/<?php echo e($haber->id); ?>">Düzenle</a>
                      
                      <form action="/admin/haber/deleteHaber" method="POST">
                        <?php echo csrf_field(); ?>
                      <input type="hidden" name="haberId" value="<?php echo e($haber->id); ?>">
                      <input class="btn btn-danger" type="submit" name="deleteHaber" value="Sil">
                      </form>
                      
                    <a href="/admin/haber/yorumlar/<?php echo e($haber->id); ?>" class="btn btn-link" href="">Yorumları Gör</a></td>
                   
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tfoot>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>