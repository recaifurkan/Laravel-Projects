 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title>Spotlar</title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="---------------" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>



<!-- //webfonts -->
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>

<div class="container pt-3">
    <div class="row py-sm-5">
        <!-- blog grid -->

        <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--    tıp klinik spot bilgiler kategorisi burada            -->

        <div class="category col-lg-4 col-md-6">



           
            <div class="card">
                <div class="">
                    <div class="card-header p-0">
                    <a href="spot/<?php echo e($kategori->url); ?>">
                        <?php
                            $resim=getFirstResim($kategori->resimler);
                        ?>
                       
                            <img class="card-img-bottom " src="<?php echo e(asset('storage/assets').'/'.$resim->url); ?>" alt="<?php echo e($resim->aciklama); ?>">
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="border-bottom py-2">
                            <h5 class="blog-title card-title font-weight-bold">
                                <a href="spot/<?php echo e($kategori->url); ?>"><?php echo e($kategori->name); ?></a>
                            </h5>
                        </div>
                        <div class="blog_w3icon pt-4">
                            <span>
                                -Ders Sayısı</span>
                            <span style="margin-left: 10px;color: white;" class="badge badge-pill badge-danger"><?php echo e($kategori->dersler->count()); ?></span>
                        </div>
                        <?php
                         $tarih = getSpotKategoriLastTarihAndSayi($kategori)[0];
                         $sayi = getSpotKategoriLastTarihAndSayi($kategori)[1];
                        ?>

                        <div class="blog_w3icon pt-4">
                            <span>
                                -Spot bilgi sayısı</span>
                            <span style="margin-left: 10px;color: white;" class="badge badge-pill badge-danger"><?php echo e($sayi); ?></span>
                        </div>

                        

                    </div>
                
                    <div class="card-footer">
                        <p class="card-text text-right">
                            <small class="text-muted"><?php echo e(getAgo($tarih)); ?></small>
                        </p>
                    </div>
                </div>
            </div>


        </div>
        <!-- //blog grid -->

        <!--    tıp klinik spot bilgiler kategorisi burada            -->    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        


       


    </div>
</div>
<?php $__env->stopSection(); ?>


<!-- icerik section sonu -->



<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>