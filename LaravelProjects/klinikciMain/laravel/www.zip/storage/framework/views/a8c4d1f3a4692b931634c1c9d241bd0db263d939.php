<footer class="py-sm-5">
    <div class="container">
        <div class="row py-5">
            <!-- footer grid1 -->
            <div class="col-lg-3 col-sm-6">
                <h2>
                    <a class="navbar-brand" href="<?php echo e(route('anasayfa')); ?>">

                        DusTus Live
                    </a>
                </h2>
                <div class="fv3-contact mt-3">

                    <p>Sağlığa Dair Herşey...</p>
                </div>


            </div>
            <!-- //footer grid1 -->
            <!-- footer grid2 -->
            <div class="col-lg-3  col-sm-6 footv3-left text-lg-center my-sm-0 mt-5">
                <h3 class="mb-3">Site Hizmetleri</h3>
                <ul class="list-agileits">
                   
                   <?php $__currentLoopData = $siteHizmetler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteHizmet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li>
                    <a href="<?php echo e(route($siteHizmet->link)); ?>">
                        <?php echo e($siteHizmet->name); ?>

                    </a>
                </li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                   

                </ul>
            </div>
            <!-- //footer grid2 -->
            <!-- footer grid3 -->
            <div class="col-lg-3  col-sm-6 footv3-left text-lg-center my-lg-0 mt-sm-5 mt-5">
                <h3 class="mb-3">Linkler</h3>


                <!--     buraya menüler gelecek      -->

                <?php $__currentLoopData = $menuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <ul class="list-agileits">
                    <li>
                        <a href="<?php echo e(route($menu->url)); ?>">
                            <?php echo e($menu->name); ?>

                        </a>
                    </li>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                


                </ul>
            </div>




            <!-- //footer grid3 -->
            <!-- footer grid4  -->
            <div class="col-lg-3  col-sm-6 footv3-left my-lg-0 mt-5">
                <h3 class="mb-3">Yeniliklerden haberdar ol</h3>
                <form action="#" method="post">
                    <div class="form-group">
                        <input type="email" class="form-control  bg-dark border-0" id="email" placeholder="E-mail giriniz" name="email" required>
                    </div>
                    <div class="form-group">
                        <input type="Submit" class="form-control bg-secondary text-white border-0" id="sub" value="Gönder" name="sub">
                    </div>
                </form>
            </div>
            <!-- //footer grid4 -->
        </div>
        <div class="cpy-right text-center  pt-5 pb-sm-0 pb-3">
            <p class="text-secondary">© 2018 DusTus Live. Tüm hakları saklıdır |
                <span  class="text-white"> RFB Yazılım</span> Tarafından dizayn edilmiştir

            </p>
        </div>
    </div>
    <!-- //footer container -->
</footer>