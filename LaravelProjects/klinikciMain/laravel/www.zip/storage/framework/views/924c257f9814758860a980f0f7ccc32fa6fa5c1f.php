<?php $__env->startSection('icerik'); ?>
<div style="margin: auto" class="text-center container col-md-7">
    <div class="box box-primary">
        <div class="box-header">
        <h3 class="box-title">Spot Ders : <?php echo e($ders->name); ?></h3>
        </div><!-- /.box-header -->
        <div>  
           
       <?php if(isset($ders->resim)): ?>
       <img width="100px" height="100px" class="card-img-bottom spotAnasayfa" src="<?php echo e(asset('storage/assets').'/'.$ders->resim->url); ?>" alt="<?php echo e($ders->resim->aciklama); ?>">
       <?php endif; ?>
          
      </div>
        <!-- form start -->
        <form  action="/admin/spot/editDers" method="POST"  enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($ders->id); ?>" name="dersId">
          <div class="box-body">

              
              <?php
              if(session()->get('hatalar')){
               $hatalar = session()->get('hatalar');
              }

              if(session()->get('succes')){
               $succes = session()->get('succes');
              }
                  
              ?>
                <?php if(isset($hatalar)): ?>
              <div class="alert-danger" >                 
                <?php $__currentLoopData = $hatalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?>                      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>
              
              
              
             
              <?php if(isset($succes)): ?>
             
              <div class="alert-success" >
                  <?php echo e($succes); ?>

               </div>
             
             
                <?php endif; ?>
             
            <div class="form-group">
              <label for="exampleInputEmail1">Ders ismi</label>
              <input value="<?php echo e($ders->name); ?>" name="dersIsim" type="text" class="form-control" placeholder="İsim Giriniz">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Açıklaması</label>
            <input value="<?php echo e($ders->aciklama); ?>" name="dersAciklama" type="text" class="form-control"  placeholder="Açıklama">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Url </label>
                <input value="<?php echo e($ders->url); ?>" name="dersUrl" type="text" class="form-control"  placeholder="url">
              </div>
              
              <div class="form-group">
                    <label for="exampleInputFile">File input</label>
                    <input name="dersResim" type="file" id="exampleInputFile">
                    <p class="help-block">Resim Seç</p>
                  </div>
           
          
          </div><!-- /.box-body -->
    
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div><!-- /.box -->

</div>






    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>