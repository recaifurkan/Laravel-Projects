 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title>DusTus Live</title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="---------------" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?> 
<?php $__env->startSection('icerik'); ?>




<!-- inner banner -->
<div class="inner_banner layer" id="home">
    <div class="container">
        <div class="agileinfo-inner">
            <h3 class="text-center text-white">
                Investment management
            </h3>
        </div>
    </div>
</div>
<!-- //inner banner -->
<!-- breadcrumbs -->
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item active" aria-current="page">About Us</li>
    </ol>
</nav>
<!-- //breadcrumbs -->

<!-- banner bottom -->
<section class="w3ls-bnrbtm py-5" id="w3layouts_bnrbtm">
    <!-- title description  -->
    <div class="container py-sm-5">
        <div class="row pt-lg-5">
            <div class="col-lg-5  bb-left">

                <h3 class="agile-title">Misyonumuz</h3>
            </div>
            <div class="col-lg-7 mt-lg-0 mt-3 px-lg-5">
                <p>Donec consequat sapien ut leo cursus rhoncus. Nullam dui mi, vulputate ac metus at, semper varius orci. Nulla
                    accumsan ac elit in congue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos
                    Class aptent taciti sociosqu ad litora torquent p himenaeos.</p>

            </div>
        </div>
    </div>
    <!-- //title description  -->
</section>
<!-- //banner bottom -->

<section class="w3ls-bnrbtm py-5" id="w3layouts_bnrbtm">
    <!-- title description  -->
    <div class="container py-sm-5">
        <div class="row pt-lg-5">
            <div class="col-lg-5  bb-left">
                <p>Donec consequat sapien ut leo cursus rhoncus. Nullam dui mi, vulputate ac metus at, semper varius orci. Nulla
                    accumsan ac elit in congue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos
                    Class aptent taciti sociosqu ad litora torquent p himenaeos.</p>

            </div>
            <div class="col-lg-7 mt-lg-0 mt-3 px-lg-5">


                <h3 class="agile-title">Vizyonumuz</h3>


            </div>
        </div>
    </div>
    <!-- //title description  -->
</section>
<!-- //banner bottom -->

<!-- //case studies -->
<!-- footer top -->
<section class="footerw3-top py-lg-5">
    <div class="container py-md-5">

        <center class="feed-title my-3">Burada Neler Yapabilirsiniz... </center>
        <!-- footer top row -->
        <div style="text-align: center;" class="row py-5 justify-content-center">




            <div class="col-md-6 my-md-0 my-4 ">
                <img src="images/f2.png" alt="" class="img-fluid">
                <h4 class="feed-title my-3">
                    <span>Yorumlar yapabilirsininz</span>
                </h4>

            </div>



            <div class="col-md-6 ">
                <img src="images/f3.png" alt="" class="img-fluid">
                <h4 class="feed-title my-3">Bilgi paylaşımı yapabilirsiniz

                </h4>

            </div>

        </div>
        <!-- //footer top row -->
    </div>
</section>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>