<div  id="captcha">
        <script src='https://www.google.com/recaptcha/api.js'></script>
        <button style="display: none" id="recaptchaButton"
        class="g-recaptcha"
        data-sitekey="<?php echo e(env('INVISIBLE_RECAPTCHA_SITEKEY')); ?>"
        data-callback="recaptchaSubmit"
        
        >
     </button>
</div> 
<script>
   
                var captchaSubmit = false;
                var forumId = "<?php echo e($forumId); ?>";
                function recaptchaSubmit(){
                    v = grecaptcha.getResponse();
                            if(v){
                               captchaSubmit = true;
                            //    console.log(captchaSubmit);
                               $(forumId).submit();

                            }
                      
                }
</script>