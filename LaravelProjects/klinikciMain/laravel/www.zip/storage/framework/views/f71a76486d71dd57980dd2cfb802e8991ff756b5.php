<?php $__env->startSection('css'); ?>

<style>
.showImage{
  width: 100px;
  height: 100px;
}
</style>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('icerik'); ?>
<div style="margin: auto" class="text-center container col-md-7">
    
        <!-- form start -->
        <?php
         $resimler = null;
        if(session()->get('resimler')){
          $resimler = session()->get('resimler');
            // var_dump($resimler);

        }
        if(session()->get('haber')){
          $haber = session()->get('haber');
        }
           
        ?>

        <?php if(!isset($resimler)): ?>
        <form  action="/admin/haber/addHaber" method="POST"  enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($kategori->id); ?>" name="kategoriId">
          <div class="box-body">

              
              <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <div class="form-group">
                <label for="exampleInputEmail1">Haber Başlığı</label>
              <input value="<?php echo e(old('haberBaslik')); ?>"  name="haberBaslik" type="text" class="form-control" placeholder="Başlık Giriniz">
              </div>
             
                
                <div class="form-group">
                  <label for="exampleInputFile">Haber içerikte kullanılacak Resimleri seçiniz</label>
                  <input value="<?php echo e(old('dersResim')); ?>"  multiple name="haberResimler[]" type="file" id="exampleInputFile">
                 
                </div>

          </div><!-- /.box-body -->
    
          <div class="box-footer">
            <button type="submit" value="Submit" name="haberResimlerSubmit" class="btn btn-primary">Submit</button>
          </div>
        </form>
        <?php else: ?>

         
            <?php $__currentLoopData = $resimler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
            <div style="z-index: 999; float: left" class="col-md-12">
                <img class="showImage" src="<?php echo e($path = asset('storage/assets').'/'.$resim->url); ?>" alt="<?php echo e($resim->aciklama); ?>" alt="">
                 <span class="copyClip"><?php echo e($path); ?></span>
                 
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
           
       
            
        <?php endif; ?>
        
        
        <div class="box box-primary">
          <div class="box-header">
          <h3 class="box-title">Haber Ekle -> <?php echo e($kategori->name); ?></h3>
          </div><!-- /.box-header -->
          <div>  
             
         
            
        </div>


        
        <hr>
        <form  action="/admin/haber/addHaber" method="POST"  enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
        <input type="hidden" name="haberId" value="<?php echo e((isset($haber->id))?$haber->id:''); ?>">
          <div class="box-body">

              
              
             
           
            <div class="form-group">
              <label for="exampleInputPassword1">Açıklaması</label>
            <input name="haberKeywords" value="<?php echo e(old('haberKeywords')); ?>" type="text" class="form-control"  placeholder="Anahtar Kelimeleri Giriniz">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Url </label>
                <input value="<?php echo e(old('haberUrl')); ?>" name="haberUrl" type="text" class="form-control"  placeholder="url">
              </div>

              <div class="form-group">
                  <label for="exampleInputPassword1">Kısa Açıklama </label>
                  <input value="<?php echo e(old('haberAciklamasi')); ?>" name="haberAciklamasi" type="text" class="form-control"  placeholder="Haber Açıklaması">
                </div>

             
                <div class="form-group">
                  <label for="exampleInputFile">Haberin Ana resmini giriniz</label>
                  <input value="<?php echo e(old('dersResim')); ?>" name="haberAnaResim" type="file" id="exampleInputFile">
                  <p class="help-block">Resim Seç</p>
                </div>
                

                  <div class="form-group">
                    <label for="exampleInputPassword1">Haber Detayı </label>
                   <textarea name="haberIcerik" class="ckeditor" ></textarea>
                   
                  </div>
           
          
          </div><!-- /.box-body -->
    
          <div class="box-footer">
            <button type="submit" value="submit" name="haberIcerikSubmit" <?php echo e(isset($haber)?'':'disabled'); ?> class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div><!-- /.box -->

</div>






    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="/admin/plugins/ckeditor/ckeditor.js"></script>


<script>
    $(function(){
     
      $('.copyClip').click(function(e) {
        var copyText=$(this);
            copyText.select();

  
          document.execCommand("copy");
          alert("Copied the text: " + copyText.value);
      });



    })
   function copy(){
    
    var copyText = document.getElementById("myInput");

    /* Select the text field */
    copyText.select();

    /* Copy the text inside the text field */
    document.execCommand("copy");
    
   }
   
   </script>




    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>