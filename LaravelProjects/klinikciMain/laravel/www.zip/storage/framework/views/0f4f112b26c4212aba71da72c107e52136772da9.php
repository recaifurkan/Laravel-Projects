<?php $__env->startSection('icerik'); ?>
<div class="row text-center">
  <div class="col-md-6">

      <div class="box-header">
          <h3 class="box-title">Slayt ekle </h3>
          </div><!-- /.box-header -->
          <!-- form start -->
          <form  action="/admin/slayt/addSlayt" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
           
            <div class="box-body">
              
                    <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
           
               
              <div class="form-group">
                <label for="exampleInputEmail1">Slayt sıra</label>
                <input value="<?php echo e(old('slaytSira')); ?>" name="slaytSira" type="number" class="form-control" >
              </div>
              <div class="form-group">
                     
                    <input id="aktifCheckbox"  name="spotIsAktif" type="checkbox" ><label for="aktifCheckbox">Slayt Aktifliği</label>
                    </div>
                  
             
                <div class="form-group">
                      <label for="exampleInputFile">Slayta eklenecek Resimler <span class="text-muted" >En fazla 2mb olmalı </span></label>
                      <input multiple name="slaytResim" type="file" id="exampleInputFile">
                      <p class="help-block">Resim Seç</p>
                    </div>
             
            
            </div><!-- /.box-body -->
      
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>
  </div>




  <div class="col-md-6"></div>
 

</div>

  
   
       
               
            
             
         
     
   
   
  









    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>