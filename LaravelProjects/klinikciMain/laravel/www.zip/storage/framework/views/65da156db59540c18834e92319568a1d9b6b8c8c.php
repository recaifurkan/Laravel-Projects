 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>
<div class="container">
    <div class="row py-sm-5">
        <!-- left grid -->
        <div class="col-lg-3 ">
            <!-- Search Widget -->
            <div class="card mb-4">

                <div class="card-body">

                    <div class="input-group">
                        <input id="search-text" class="form-control" placeholder="Haberlerde Ara" type="text">
                        <span class="input-group-btn">
                                        <button id="search" class="btn btn-secondary" type="submit">Ara</button>
                                    </span>
                    </div>

                </div>
            </div>


            <!-- arama sonuçları -->
            <!-- arama sonucunda açılacak -->
            <!-- latest post -->
            <div style="display: none;" id="search-result" class="row">
                <div class="card my-4 p-3 post_link col-md-12 ">
                    <h5 class=" card-header"><span class="badge badge-info" id="aranan-kelime"></span><span class=""> için sonuçlar</span> </h5>


                    <!-- arama sonuçlarında tekrar edecek yer          -->
                    <div class="row mt-3">
                        <div class="col-4">
                            <a href="blog.html">
                                <img class="card-img-bottom" src="images/img2.jpg" alt="Card image cap">
                            </a>
                        </div>
                        <div class="col-8 pl-0">
                            <a href="blog.html">eveniie arcet ut moles morbi dapiti</a>
                            <p class="card-text">
                                <small class="text-muted">26 April,2018</small>
                            </p>
                        </div>
                    </div>

                    <!-- arama sonucunda tekrar edecek yer         -->

                </div>



            </div>

            <!-- arama sonucunda açılacak yer -->


            <!-- Categories Widget -->
            <div class="card my-4">
                <h5 class="card-header">Kategoriler</h5>
                <div class="card-body">
                    <ul class="w3-tag2">


                        <!--     kategorilerd etekrar ettirilecekle burası       -->
                        <li>
                            <a href="single.html">
                                <i class="fa fa-angle-right mr-2"></i>dictumamet</a>
                        </li>

                        <!--     kategorilerd etekrar ettirilecekle burası       -->

                    </ul>
                </div>
            </div>
            <!-- Side Widget -->

            <!-- latest post -->
            <div class="card my-4 p-3 post_link">
                <h5 class="card-header">En son Haberler</h5>


                <!-- en son haberlerde tekrar ettirilecek yer          -->
                <div class="row mt-3">
                    <div class="col-4">
                        <a href="blog.html">
                            <img class="card-img-bottom" src="images/img2.jpg" alt="Card image cap">
                        </a>
                    </div>
                    <div class="col-8 pl-0">
                        <a href="blog.html">eveniie arcet ut moles morbi dapiti</a>
                        <p class="card-text">
                            <small class="text-muted">26 April,2018</small>
                        </p>
                    </div>
                </div>

                <!-- en son haberlerde tekrar ettirilecek yer          -->

            </div>
        </div>
        <!-- //left grid -->
        <!-- right grid -->
        <div class="col-lg-9">



            <!--    haber tekrar ettirilecek yer başlangıç          -->




            <!-- blog grid -->
            <div class="card">
                <div class="row no-gutters">
                    <div class="col-md-8">
                        <div class="card-body">
                            <div class="d-sm-flex justify-content-between  border-bottom py-2">
                                <h5 class="blog-title card-title font-weight-bold">
                                    <a href="single.html">Blog Title</a>
                                </h5>
                                <div class="blog_w3icon">
                                    <span>
                                        <i class="fas fa-user mr-2"></i>Stella</span>
                                    <span class="ml-sm-3 ml-2">
                                        <i class="fab fa-servicestack mr-2"></i>Funding Trends</span>
                                </div>
                            </div>
                            <p class="card-text mt-3">Cras ultricies ligula sed magna dictum porta. Mauris blandit aliquet elit, eget tincidunt nibh
                                pulvinar a. Pellentesque in ipsum id orci porta sed magna dictum dapibus.</p>
                            <a href="single.html" class="blog-btn text-dark">Read more</a>
                            <p class="card-text">
                                <small class="text-muted">Last updated 3 mins ago</small>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <a href="single.html">
                            <img class="card-img-bottom" src="images/imgr4.jpg" alt="Card image cap">
                        </a>
                    </div>
                </div>
            </div>
            <!-- //blog grid -->

            <!--    haber tekrar ettirilecek yer başlangıç          -->

        </div>
        <!-- //right grid -->
    </div>

</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>






<script>
    $(function(){
          
    $('#search-text').on('input',function(e){
        if($(this).val()==''){
            $('#search-result').slideUp();
        }
        else{
           
            $('#search-result').slideDown();
            $('#aranan-kelime').html($(this).val());
        }

});

});
</script>




<script>
    $("#search").click(function(){
            
            $('#search-result').slideToggle();  // burada arama submit edilince açılıp kapanma gösterilcek


        });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>