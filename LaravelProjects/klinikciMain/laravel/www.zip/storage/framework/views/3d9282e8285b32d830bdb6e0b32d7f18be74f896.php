 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title><?php echo e($kategori->name); ?></title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="<?php echo e($kategori->keywords); ?>" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>

<div class="container">

    <!-- breadcrumbs -->
    <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="/spot">Spot</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e($kategori->name); ?>

                </li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
</div>



       <?php if(!$dersler->first()): ?>
       
       <?php echo $__env->make('components.eklenmedi',['olmayan'=>'spot'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


       <?php else: ?>
       

    <div class="container">
        
      

       <?php $__currentLoopData = $dersler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <div class="row py-lg-5">
       <div class="card category">
           <div class="row no-gutters">

               <div class="col-md-8">
                   <div class="card-body">
                       <div class="d-sm-flex justify-content-between border-bottom py-2">



                           <h5 class="blog-title card-title font-weight-bold">
                           <a href="<?php echo e($ders->kategori->url); ?>/<?php echo e($ders->url); ?>"><?php echo e($ders->name); ?></a>
                           </h5>
                           <div class="col-md-2">
                               <a href="<?php echo e($ders->kategori->url); ?>/<?php echo e($ders->url); ?>">
                                   
                                   <img width="80px;" src="<?php echo e(asset('storage/assets').'/'.$ders->resim->url); ?>" alt="<?php echo e($ders->resim->aciklama); ?>">
                               </a>
                           </div>

                       </div>
                   <p class="card-text mt-3"><?php echo e($ders->aciklama); ?></p>
                       <a href="<?php echo e($ders->kategori->url); ?>/<?php echo e($ders->url); ?>" class="blog-btn text-dark">Ders Git</a>
                       
                   </div>
               </div>
               <div style="line-height: 75px;" class="col-md-4">

                   <ul class="list-group  ">
                       <li class="list-group-item d-flex justify-content-between align-items-center">
                           Toplam Ünite Sayısı
                       <span class="badge badge-primary badge-pill"><?php echo e(getDersUnitelerAdet($ders)); ?></span>
                       </li>
                       <li class="list-group-item d-flex justify-content-between align-items-center">
                           Spot bilgi sayısı
                           <span class="badge badge-primary badge-pill"><?php echo e(getDersSpotlarAdet($ders)); ?></span>
                       </li>
                       <li class="list-group-item d-flex justify-content-between align-items-center">
                           Toplam Görüntülenme
                           <span class="badge badge-primary badge-pill"><?php echo e(getSpotDersGoruntulenme($ders)); ?></span>
                       </li>
                   </ul>



               </div>

           </div>
       </div>
    </div>

           
       


      
      
       <!-- //blog grid -->
       <!--   dersler için tekrarlanacak yer burası aman dikkat ders içerik uzun olsun       -->
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <?php echo e($dersler->links()); ?>

           
       <?php endif; ?>

       
        
       
        <!--   dersler için tekrarlanacak yer burası aman dikkat ders içerik uzun olsun       -->
        
        <!-- blog grid -->
        
        

    
</div>
<?php $__env->stopSection(); ?>


<!-- icerik section sonu -->



<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>