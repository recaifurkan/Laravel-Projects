<?php if(!Auth::check()): ?>
<div style="text-align: center;">
<p>Yorum yapabilmek için lütfen giriş yapınız...</p>

<button type="button" class="btn btn-danger ml-lg-5 w3ls-btn" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">
    Giriş Yap
    </button>
</div>
   

  
<?php else: ?>  

<div class="form-group">
        <form action="#" method="get" class="f-color p-3">
                <?php echo e(csrf_field()); ?>

        <input type="hidden" name="spotid" value="<?php echo e($spot->id); ?>">
            <label for="contactcomment">Yorumunuz</label>
            
            <textarea id="contactcomment" name="yorumText"></textarea>

        </div>
        <button type="submit" name="spotYorum" class="mt-3 btn btn-danger btn-block">Yorumu gönder</button>
    </form>

<?php endif; ?>