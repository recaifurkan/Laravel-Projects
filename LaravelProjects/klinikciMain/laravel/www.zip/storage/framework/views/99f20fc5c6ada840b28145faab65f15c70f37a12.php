
<?php $__currentLoopData = $haberler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $haber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- blog grid -->
    <div class="col-lg-6 col-md-6 haber_card">
        <div class="card">
            <div class="card-header p-0">
                <a href="haber/<?php echo e($haber->url); ?>">
                    <?php
                    $resim=getFirstResim($haber->resimler);
                        
                    ?>
                    <img class="card-img-haber" src="<?php echo e(asset('storage/assets').'/'.$resim->url); ?>" alt="<?php echo e($resim->aciklama); ?>">
                </a>
            </div>
            <div class="card-body">
                <div class="border-bottom py-2">
                    <h5 class="blog-title card-title font-weight-bold">
                        <a href="single.html"><?php echo e($haber->baslik); ?></a>
                    </h5>
                </div>
                <div class="blog_w3icon pt-4">
                    <span>
                        <i class="fas fa-user mr-2"></i><?php echo e($haber->user->name); ?></span>
                    <span class="ml-3">
                            <i class="far fa-eye"></i><?php echo e($haber->hit); ?> </span>
                </div>
                <p class="card-text mt-3"><?php echo e($haber->kisa_aciklama); ?></p>
                <a href="haber/<?php echo e($haber->url); ?>" class="blog-btn text-dark">Habere git</a>
            </div>
            <div class="card-footer">
                <p class="card-text text-right">
                    <small class="text-muted"><?php echo e($haber->eklenme_tarihi); ?></small>
                </p>
            </div>
        </div>
    </div>
    <!-- //blog grid -->

    <!-- haber tekrar edilecek burada -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>