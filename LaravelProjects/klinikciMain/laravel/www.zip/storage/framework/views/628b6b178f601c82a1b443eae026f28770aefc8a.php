 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>







<!--  başlık belirtilecek  -->



<?php $__env->startSection('title'); ?>
<title>DusTus Live</title>
<?php $__env->stopSection(); ?>




<!-- keywordlar belirtilecek -->



<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="---------------" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>



<!-- Services section -->
<section class=" " id="we_offer_agile">
    <div class="container py-md-5 py-3">

        <div style="width: auto;" class="services-bot-agile ">
            <div class="row mt-5">




                <div class="col-lg-4 col-sm-6">
                    <div class="card">
                        <div class="card-block block-1">
                            <h3 class="card-title">
                                <span>K</span>onu Adı </h3>

                            <a href="#" title="Spotlara Git" class="read-more">Spotlara Git
                                <i class="fa fa-angle-double-right ml-2"></i>
                            </a>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-sm-6">
                    <div class="card">
                        <div class="card-block ">
                            <h3 class="card-title">
                                <span>K</span>onu Adı </h3>

                            <a href="#" title="Spotlara Git" class="read-more">Spotlara Git
                                <i class="fa fa-angle-double-right ml-2"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="card">
                        <div class="card-block block-6">
                            <h3 class="card-title">
                                <span>K</span>onu Adı </h3>
                            <p class="card-text">Donec rutrum congue leo eget malesuada.</p>
                            <a href="#" title="Spotlara Git" class="read-more">Spotlara Git
                                <i class="fa fa-angle-double-right ml-2"></i>
                            </a>
                        </div>
                    </div>
                </div>












            </div>
        </div>
    </div>
</section>
<!-- /Services section -->
<?php $__env->stopSection(); ?>



<!-- icerik section sonu -->




<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>