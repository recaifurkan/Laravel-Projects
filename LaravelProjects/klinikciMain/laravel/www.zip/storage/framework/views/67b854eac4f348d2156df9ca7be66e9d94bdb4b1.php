 <!-- header -->
 <header>
    <div class="container">
        <!-- nav -->
        <nav class="navbar navbar-expand-lg navbar-light py-4">
            <!-- logo -->
            <h1 style="width:200px;">
                <a class="navbar-brand" href="index.html">
                    DusTus Live
                </a>
            </h1>
            <!-- //logo -->
            <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- main nav -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-lg-auto text-center">



                    <!-- menilerin başlangıcı         -->
                    <li class="nav-item active  mr-lg-3">
                        <a class="nav-link" href="index.html">Anasayfa
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>



                    <!--        giriş işlemi yapılacak yer            -->
                    <li>
                        <button type="button" class="btn btn-danger ml-lg-5 w3ls-btn" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">
                            Giriş Yap
                        </button>
                    </li>
                </ul>
            </div>
            <!-- //main nav -->
        </nav>
        <!-- //nav -->
    </div>
</header>
<!-- //header -->