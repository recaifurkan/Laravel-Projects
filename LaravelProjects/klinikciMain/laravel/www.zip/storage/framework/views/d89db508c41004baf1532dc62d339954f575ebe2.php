 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>


<div class="container pt-lg-5">
    <div class="row py-lg-5">

        <!-- konu açılış mesajı       -->
      
        <!-- blog grid -->
        <div class="card categorys">
                <div  class="badge badge-pill badge-danger">Konu Açılış Mesajı</div>
            <div class="row no-gutters">
                <div class="col-md-3">

                    <div style="text-align: center" class="col-md-12">
                       <div>
                            
                                    <img width="50%" class="text-center" src="<?php echo e(asset('storage/assets').'/'.$konu->user->profilResim->url); ?>" alt="<?php echo e($konu->user->name); ?>">
                            


                       </div>
                       
                        <span class="badge badge-pill badge-secondary"><?php echo e($konu->user->name); ?></span>
                        
                    
                        <br>
                        <span class="badge badge-pill badge-info">Konu Sahibi
                            <i class="fas fa-check-double"></i>
                        </span>
                        <br>
                        <?php
                                $mesajSayisi = $konu->user->formKonuMesajlar->count() + $konu->user->formKonular->count();
                            ?>
                        <span>Toplam</span>
                        <span class="badge badge-pill badge-info"> <?php echo e($mesajSayisi); ?></span>
                        <span>mesaj</span>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="card-body">
                        <div class="d-sm-flex justify-content-between border-bottom py-2">

                            <div class="blog_w3icon">

                                <span>
                                    <i class="far fa-comments"></i><?php echo e($konu->mesajlar->count()); ?></span>
                                <span>
                                    <i class="far fa-eye"></i><?php echo e($konu->goruntulenme_sayisi); ?></span>
                                    <span><i class="fas fa-comments"><?php echo e($konu->mesajlar->count()); ?></i></span>
                                    <small class="text-muted">
                                            <span class="ml-3">
                                                    <i class="far fa-calendar-alt"></i><?php echo e(getAgo($konu->acilis_tarihi)); ?></span>
                                            </small>
                                
                                

                                <button class="badge badge-pill badge-warning">
                                    <span>
                                        <i class="far fa-thumbs-up"></i><?php echo e($konu->begenilme_sayisi); ?></span>
                                    </button>


                            </div>
                        </div>
                        <p class="card-text mt-3"><?php echo e($konu->aciklama); ?></p>

                        
                    </div>
                </div>
            </div>
        </div>
        <!-- //blog grid -->
        <!-- konu açılış mesajı       -->

    </div>


</div>
<hr>
<!--     burada da diğüer mesajlar listelenecek        -->
<div class="container pt-lg-5">
    <div class="row py-lg-5">
        <?php
            $mesajlar = $konu->mesajlar()->paginate(6);


        ?>

        <?php $__currentLoopData = $mesajlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesaj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        

        <!-- konu içindeki diğer mesajlar      -->
            <!-- blog grid -->
            <div class="card categorys">
                <div class="row no-gutters">
                    <div class="col-md-3">

                        <div style="text-align: center" class="col-md-12">
                           <div>
                                <a href="single.html">
                                        <img width="50%" class="text-center" src="<?php echo e(asset('storage/assets').'/'.$mesaj->user->profilResim->url); ?>" alt="<?php echo e($mesaj->user->name); ?>">
                                </a>


                           </div>
                            
                            <span class="badge badge-pill badge-secondary"><?php echo e($mesaj->user->name); ?></span>

                            <?php if($konu->user->id == $mesaj->user->id): ?>
                            <br>
                            <span class="badge badge-pill badge-info">Konu Sahibi
                                <i class="fas fa-check-double"></i>
                            </span>
                            <?php endif; ?>
                            
                            <br>
                            <?php
                                $mesajSayisi = $mesaj->user->formKonuMesajlar->count() + $mesaj->user->formKonular->count();
                            ?>
                            <span>Toplam</span>
                            <span class="badge badge-pill badge-info"><?php echo e($mesajSayisi); ?></span>
                            <span>mesaj</span>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="card-body">
                            <div class="d-sm-flex justify-content-between border-bottom py-2">

                                <div class="blog_w3icon">
                                 <small class="text-muted"> <span class="ml-3">
                                                <i class="far fa-calendar-alt"></i><?php echo e(getAgo($mesaj->yazilma_tarihi)); ?> </span></small>
                                                <button class="badge badge-pill badge-warning">
                                                        <span>
                                                            <i class="far fa-thumbs-up"></i><?php echo e($mesaj->begeni); ?></span>
                                                        </button>


                                </div>
                            </div>
                            <p class="card-text mt-3"><?php echo e($mesaj->icerik); ?></p>

                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- //blog grid -->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <!--konu içindeki diğer mesajlar      -->

        <div style="margin: auto; margin-top: 10px;"><?php echo e($mesajlar->links()); ?></div>



    </div>



</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>