<?php $__currentLoopData = $konular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="row ">
                   
        <div class="col-md-6 text-center ">
            <a href="<?php echo e($konu->kategori->url); ?>/<?php echo e($konu->url); ?>"><?php echo htmlspecialchars_decode($konu->name); ?></a>
    
        </div>
        <div class="col-md-6 text-muted">
                <span class="card-text"> <?php echo e(getAgo($konu->acilis_tarihi)); ?></span>
                <span><i class="far fa-eye"><?php echo e($konu->goruntulenme_sayisi); ?></i></span>
                <span class="badge badge-pill badge-danger"><i class="far fa-thumbs-up"></i> <?php echo e($konu->begenilme_sayisi); ?></span>
                <?php if(Auth::check()&& !userLikeKonu($konu)): ?> 
                                        
                <span class="justify-content-center">
                        <a href="" class="badge konuBegen spotBegen" style="height: 25px;line-height: 19px;"  > Beğen</a>
                        <form class="konuBegen" style="display: none;" action='/konuBegen' method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="konuId" value="<?php echo e($konu->id); ?>">
                        
                        </form>
                    </span> 
               
                <?php endif; ?>
            
            </div>
    
     
    
    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
