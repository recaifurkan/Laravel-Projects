<?php $__env->startSection('icerik'); ?>
<div class="row text-center">
  <div class="col-md-6">

      <div class="box-header">
          <h3 class="box-title">Spot ekle -> <?php echo e($unite->name); ?></h3>
          </div><!-- /.box-header -->
          <!-- form start -->
          <form  action="/admin/spot/addSpot" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($unite->id); ?>" name="uniteId">
            <div class="box-body">
              
               
              <?php
              if(session()->get('hatalar')){
               $hatalar = session()->get('hatalar');
              }
              if(session()->get('succes')){
               $succes = session()->get('succes');
              }
                  
              ?>
                <?php if(isset($hatalar)): ?>
              <div class="alert-danger" >                 
                <?php $__currentLoopData = $hatalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?>                      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>
              
              
              
             
              <?php if(isset($succes)): ?>
             
              <div class="alert-success" >
                  <?php echo e($succes); ?>

               </div>
             
             
                <?php endif; ?>
           
               
              <div class="form-group">
                <label for="exampleInputEmail1">Spot</label>
                <input value="<?php echo e(old('spotIcerik')); ?>" name="spotIcerik" type="text" class="form-control" placeholder="İçerik yazınız">
              </div>
              <div class="form-group">
                      <label for="exampleInputPassword1">Url</label>
                    <input value="<?php echo e(old('spotUrl')); ?>" name="spotUrl" type="text" class="form-control"  placeholder="Url">
                    </div>
                    <div class="form-group">
                          <label for="exampleInputPassword1">Anahtar Kelime Griniz <span class="text-muted">',' ile ayırınız</span></label>
                        <input value="<?php echo e(old('spotUrl')); ?>" name="spotkeywords" type="text" class="form-control"  placeholder="Url">
                        </div>
             
             
             
                <div class="form-group">
                      <label for="exampleInputFile">Spot eklenecek Resimler <span class="text-muted" >En fazla 2mb olmalı </span></label>
                      <input multiple name="spotResim[]" type="file" id="exampleInputFile">
                      <p class="help-block">Resim Seç</p>
                    </div>
             
            
            </div><!-- /.box-body -->
      
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>
  </div>




  <div class="col-md-6"></div>
 

</div>

  
   
       
               
            
             
         
     
   
   
  









    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>