 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title>DusTus Live</title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="---------------" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>

<body>

    <!-- inner banner -->
    <div class="inner_banner layer" id="home">
        <div class="container">
            <div class="agileinfo-inner">
                <h3 class="text-center text-white">
                    Bilgi Paylaşarak Çoğalır...
                </h3>
            </div>
        </div>
    </div>
    <!-- //inner banner -->
    <!-- breadcrumbs -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/">Anasayfa</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                    İletişim
            </li>
        </ol>
    </nav>
    <!-- //breadcrumbs -->
    <!-- contact -->
    <section class="wthree-row w3-contact" id="contact">
        <div class="container py-sm-5 py-4">
            <!-- title description  -->
            <div class="row py-md-5 pb-3">
                <div class="col-lg-5  bb-left">
                    <span class="w3-line">Merhaba deyin</span>
                    <h3 class="agile-title">Bizimle iletişime Geçin</h3>
                </div>
                <div class="col-lg-7 mt-lg-0 mt-3 px-lg-5">
                    <p>Aklınıza gelebilecek her türlü sorun, görüş,destek için bize buradan ulaşabilirsiniz. En kısa sürede
                        geri dönüş yapılacaktır.</p>
                </div>
            </div>
            <!-- //title description  -->
            <!-- contact details -->
            <div class="row contact-form p-sm-5 p-3">

                <!-- contact right grid -->
                <div class="col-lg-12 wthree-form-left mt-lg-0 mt-3">
                    <!-- contact form grid -->
                    <div class="contact-top1">
                        <h5 class="my-3">Bize bir mesaj gönderin</h5>
                        <form action="#" method="get" class="f-color pt-3">
                            <div class="form-group">
                                <label for="contactusername">İsim</label>
                                <input type="text" class="form-control" id="contactusername" required>
                            </div>
                            <div class="form-group my-4">
                                <label for="contactemail">E-mail</label>
                                <input type="email" class="form-control" id="contactemail" required>
                            </div>
                            <div class="form-group">
                                <label for="konuusername">Konu</label>
                                <input type="text" class="form-control" id="konuusername" required>
                            </div>
                            <div class="form-group">
                                <label for="contactcomment">Mesajınız</label>
                                <textarea class="form-control" rows="5" id="contactcomment" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-danger btn-block">Gönder</button>
                        </form>
                    </div>
                </div>
                <!--  //contact right grid -->
            </div>
            <!-- //contact details  -->
        </div>
    </section>
    <!-- //contact -->
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>