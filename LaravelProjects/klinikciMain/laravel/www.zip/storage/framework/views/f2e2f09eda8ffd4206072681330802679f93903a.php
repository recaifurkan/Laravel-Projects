 <!-- header -->
 <header>
    <div class="container">
        <!-- nav -->
        <nav class="navbar navbar-expand-lg navbar-light py-4">
            <!-- logo -->
            <h1 id="logo-h1" style="width:200px;">
                <a class="navbar-brand" href="<?php echo e(route('anasayfa')); ?>">
                    <?php echo e($siteBilgiler->site_name); ?>

                </a>
            </h1>
            <!-- //logo -->
            <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- main nav -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-lg-auto text-center">


                    <?php $__currentLoopData = $menuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li class="nav-item active  mr-lg-3">
                    <a class="nav-link" href="<?php echo e(route($menu->url)); ?>"><?php echo e($menu->name); ?>

                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- menilerin başlangıcı         -->
                   



                    <!--        giriş işlemi yapılacak yer            -->
                    <li>
                        <button type="button" class="btn btn-danger ml-lg-5 w3ls-btn" data-toggle="modal" aria-pressed="false" data-target="#exampleModal">
                            Giriş Yap
                        </button>
                    </li>
                </ul>
            </div>
            <!-- //main nav -->
        </nav>
        <!-- //nav -->
    </div>
</header>
<!-- //header -->

 <!-- Login modal -->
 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Login</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="#" method="post">
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Kullanıcı Adı</label>
                        <input type="text" class="form-control border" placeholder="Kullanıcı adınızı giriniz... " name="Name" id="recipient-name"
                            required="">
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-form-label">Şifre</label>
                        <input type="password" class="form-control border" placeholder="Şifrenizi giriniz... " name="Password" id="password" required="">
                    </div>
                    <div class="right-w3l">
                        <input type="submit" class="form-control border text-white" value="Login">
                    </div>
                    <div class="row sub-w3l my-3">
                        <div class="col sub-agile">
                            <input type="checkbox" id="brand1" value="">
                            <label for="brand1" class="text-muted">
                                <span></span>Beni Hatırla</label>
                        </div>
                        <div class="col forgot-w3l text-right text-dark">
                            <a href="#" class="text-white">Şifrenizi mi unuttunuz?</a>
                        </div>
                    </div>
                    <p class="text-center">Hesabınız Yok mu?
                        <a href="#" data-toggle="modal" data-target="#exampleModal1" class="text-dark font-weight-bold">
                            Hesap oluştur</a>
                    </p>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- //Login modal -->
<!-- Register modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Register</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="#" method="post">
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Kullanıcı Adı</label>
                        <input type="text" class="form-control border" placeholder=" " name="Name" id="recipient-rname" required="">
                    </div>
                    <div class="form-group">
                        <label for="recipient-email" class="col-form-label">E-mail</label>
                        <input type="email" class="form-control border" placeholder=" " name="Email" id="recipient-email" required="">
                    </div>
                    <div class="form-group">
                        <label for="password1" class="col-form-label">Şifre</label>
                        <input type="password" class="form-control border" placeholder=" " name="Password" id="password1" required="">
                    </div>
                    <div class="form-group">
                        <label for="password2" class="col-form-label">Şifre</label>
                        <input type="password" class="form-control border" placeholder=" " name="Confirm Password" id="password2" required="">
                    </div>
                    <div class="sub-w3l">
                        <div class="sub-agile">
                            <input type="checkbox" id="brand2" value="">
                            <label for="brand2" class="mb-3">
                                <span></span>Okudum ve şartları kabul ediyorum</label>
                        </div>
                    </div>
                    <div class="right-w3l">
                        <input type="submit" class="form-control bg-light text-white" value="Register">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- // Register modal -->