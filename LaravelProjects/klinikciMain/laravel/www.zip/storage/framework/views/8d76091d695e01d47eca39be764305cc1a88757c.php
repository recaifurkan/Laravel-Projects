 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<title> <?php echo htmlspecialchars_decode(ilkHarfBuyuk($kategori->name)); ?>  : Forum </title>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>
<div class="container">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                     <li class="breadcrumb-item" aria-current="page">
                  <a href="/forum">Forum</a>
                     </li>
                     <li class="breadcrumb-item active " aria-current="page">
                     <?php echo e(ilkHarfBuyuk($kategori->name)); ?>

                              </li>
                   
                   
                    
                      
                   
                </ol>
            </nav>
            <!-- //breadcrumbs -->
        </div>

 <?php echo $__env->make('forumKategoriyeKonuEkle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container" style="text-align: center">
     <?php echo $__env->make('components.forumKonuArama', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
    <section>
        
            <!-- arama sonucunda açılacak yer -->

             <!-- latest post -->
             <div class="row">
                <div class="card my-4 p-3 post_link col-md-12 ">
                <h5 class="card-header"><?php echo htmlspecialchars_decode(ilkHarfBuyuk($kategori->name)); ?></h5>
 
 
                    <!--     konunun limki buraya koyulacak        -->
 
                   
                   
                    <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $kategoriKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   
                   
                   
                   
                    <!--     konunun limki buraya koyulacak        -->
 
                </div>
 
 
 
            </div>


            <div class="row ">
                    <div style="margin: auto"><?php echo e($kategoriKonular->links()); ?></div>

            </div>
                   

            
      
 
            <!-- farklı konudaki konuların gösterilmesi gereken yer -->



            






        
    </section>
</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>

<?php if(Auth::check()): ?>
                                     
            <script>
                    // burada beğeni tuşu ayarlaması yapıldı
                                $(function(){
                
                            $('.konuBegen').click(function(e){
                                e.preventDefault();
                                var form = $(this).next();
                                
                                // console.log(form);
                                
                
                            $.ajax({
                            type: "POST",
                            url: form.attr('action'),
                            data: form.serialize() ,
                            success: function (data){
                                
                                // console.log(data);
                                location.reload();
                            },
                
                            });
                
                
                            });
                
                
                            });
                
                // burada beğeni tuşu ayarlaması yapıldı
                    </script>

                    <?php endif; ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>