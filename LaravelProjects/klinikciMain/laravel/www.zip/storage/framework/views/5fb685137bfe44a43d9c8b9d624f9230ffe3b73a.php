<?php $__env->startSection('css'); ?>
    <!-- DATA TABLES -->
    <link href="/admin/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Haberler
        
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                   
                    <th>İsim</th>
                    <th>Url</th>
                    <th>Açıklama</th>
                    <th>Kategorisi</th>
                    <th>İşlemler</th>
                    
                  </tr>
                </thead>
                <tbody>
                    <tr>
                        <form action="/admin/haber/addKategori" method="post">
                          <?php echo csrf_field(); ?>
                          
                     
                      <td><input class="form-control" type="text" name="kategoriName" placeholder="Yeni Kategori İsmi" value="<?php echo e(old('kategoriName')); ?>"> </td>
                      <td><input class="form-control" type="text" name="kategoriUrl" placeholder="Yeni Kategori Url" value="<?php echo e(old('kategoriUrl')); ?>">  </td>
                      <td><input class="form-control" type="text" name="kategoriAciklama" placeholder="Yeni Kategori Açıklaması" value="<?php echo e(old('kategoriAciklama')); ?>"> </td>
                      
                      <td><select class="form-control" name="ustKategori" >
                        <option value="0">Üst kategorisi Yok</option>
                        <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriSelect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                        <option value="<?php echo e($kategoriSelect->id); ?>"><?php echo e($kategoriSelect->name); ?> </option>
                      
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </select>
                    </td>
                      <td>
                        <input class="btn btn-success" value="Ekle" name="Ekle" type="submit">
                      
                      </td>
                    </form>
                    </tr>
                  <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                   
                 <tr>
                    <form action="/admin/haber/editKategori" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="kategoriId" value="<?php echo e($kategori->id); ?>">
                 
                  <td><input class="form-control" type="text" name="kategoriName" value="<?php echo e($kategori->name); ?>"> </td>
                  <td><input class="form-control" type="text" name="kategoriUrl" value="<?php echo e($kategori->url); ?>">  </td>
                  <td><input class="form-control" type="text" name="kategoriAciklama" value="<?php echo e($kategori->aciklama); ?>"> </td>
                  
                  <td><select class="form-control" name="ustKategori" >
                    <option value="0">Üst kategorisi Yok</option>
                    <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriSelect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($kategori!=$kategoriSelect): ?>
                    <option value="<?php echo e($kategoriSelect->id); ?>"
                      
                        <?php echo e($kategori->ustkategori ? 
                        (($kategori->ustKategori->id == $kategoriSelect->id) ? 'selected':''):''); ?> >
                        <?php echo e($kategoriSelect->name); ?>

                   </option>
                    <?php endif; ?>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  
                  </select>
                </td>
                 
                  <td>
                    <input class="btn btn-info" value="Düzenle" name="submitDuzenle" type="submit">
                    <input class="btn btn-danger" value="Sil" name="submitDelete" type="submit">
                  <a class="alert-secondary " href="/admin/haber/haberler/<?php echo e($kategori->id); ?>">Haberleri Gör</a>
                  </td>
                </form>
                </tr>
             
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                 
                 
                </tfoot>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>