<div class="contact-top1">
        <script src="https://cdn.ckeditor.com/ckeditor5/11.0.1/classic/ckeditor.js"></script>

        <h1>Yorumlar</h1>
            <hr>
        <!-- burası yorum yap kısmı -->
        <a id="yorumButton" href=""><h5 class="text-dark text-danger mb-4 text-capitalize">Bir yorum yap</h5></a>
        <div>
       
           
            <?php if(!Auth::check()): ?>
            <div style="text-align: center;">
            <p>Yorum yapabilmek için lütfen giriş yapınız...</p>

            <button type="button" class="btn btn-danger ml-lg-5 w3ls-btn" data-toggle="modal" aria-pressed="false" data-target="#exampleModel">
                    Giriş Yap
                </button>
            </div>
               

              
            <?php else: ?>  
            
            <div class="form-group">
                    <form action="/spot" method="POST" class="f-color p-3">
                        <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="spotid" value="<?php echo e($spot->id); ?>">
                        <label for="contactcomment">Yorumunuz</label>
                        <textarea style="width: 100%" placeholder="Yorumunuz" name="yorumText" class="yorumText"></textarea>
                       

                    </div>
                    <button type="submit" value="spotYorum" name="spotYorum" class="mt-3 btn btn-danger btn-block">Yorumu gönder</button>
                </form>
            
            <?php endif; ?>
              
            
        
    </div>




<?php $__currentLoopData = $yorumlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yorum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!--      yorum tekrar edilecek kısım         -->
<div class="media py-5">
    <img class="mr-3" src="<?php echo e(asset('storage/assets').'/'.$yorum->user->profilResim->url); ?>" alt="<?php echo e($yorum->user->name); ?>">
    <div class="media-body">
        <h5 class="mt-0"><?php echo e($yorum->user->name); ?></h5>
        <p><?php echo htmlspecialchars_decode($yorum->icerik); ?>

        </p>
        <p><?php echo e(getAgo($yorum->eklenme_tarih)); ?> </p>
        <a class="cevaplaButton" href=""><span><i class="fas fa-reply"></i>Cevapla</span></a>
        

        <!--  alt yorum için -->



        <?php if(!Auth::check()): ?>

        <div style="display: none;text-align: center;">
            <p>Cevap verebilmek için lütfen giriş yapınız...</p>

            <button id="loginButton" type="button" class="btn btn-danger ml-lg-5 w3ls-btn" data-toggle="modal" aria-pressed="false" data-target="#exampleModel">
                    Giriş Yap
                </button>
        </div>


        <?php else: ?>
       
        <div style="display: none;">

            <form action="/spot" method="POST" class="f-color p-3">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                <input type="hidden" name="ustYorum" value="<?php echo e($yorum->id); ?>">
                    
                <textarea style="width: 100%" placeholder="Yorumunuz" name="altYorumText" class="yorumText"></textarea>
                   </div>
                <button type="submit" value="altYorum" name="altYorum" class="mt-3 btn btn-danger btn-block">Yorumu gönder</button>
            </form>
        </div>
        <?php endif; ?>
    <?php echo $__env->make('yorum-kisim.altyorumlar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
</div>

<!--      yorum tekrar edilecek kısım         -->



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<script>
    $(function(){

         $('.yorumText').each(function(index,elem){
        // console.log(elem);

         ClassicEditor.create(elem,{
                toolbar: [  'bold', 'italic', 'link' ],
                heading: {
                options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
                ]
                }
                });





    });


   $('.cevaplaButton').click(function(e){
       e.preventDefault();
       $(this).next().slideToggle();


   });

        





    });
   
                
</script>

