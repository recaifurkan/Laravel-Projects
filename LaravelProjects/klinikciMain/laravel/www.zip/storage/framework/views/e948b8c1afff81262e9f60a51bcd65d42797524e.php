<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Sınavlar
        
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    
                    <th>Sınav Türü</th>
                    <th>Sınav Tarihi</th>
                    <th>İşlemler</th>
                   
                    
                  </tr>
                </thead>
                <tbody>
                 
                    <?php $__currentLoopData = $sinavlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sinav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <form action="/admin/sinav/editSinav" method="POST">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="sinavId" value="<?php echo e($sinav->id); ?>">
                    
                    <td><?php echo e($sinav->sinav_tur); ?></td>
                    <td><input type="date" name="sinavTarih" value="<?php echo e(date('Y-m-d', strtotime($sinav->sinav_tarih))); ?>"></td>
                    <td><input class="btn btn-info" value="Düzenle" type="submit"></td>
                  </form>
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   
                
                 
                </tfoot>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>