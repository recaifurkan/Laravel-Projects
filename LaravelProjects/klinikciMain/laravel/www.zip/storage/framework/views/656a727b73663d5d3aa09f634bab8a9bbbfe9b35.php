 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title><?php echo e(ilkHarfBuyuk($spot->icerik)); ?></title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="<?php echo e($spot->keywords); ?>" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/smartphoto.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>
   

<div class="container">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/spot">Spot</a>
                    </li>
                    <li class="breadcrumb-item">
                            <a href="../../../<?php echo e($spot->unite->ders->kategori->url); ?>"><?php echo e($spot->unite->ders->kategori->name); ?></a>
                                </li>
                    <li class="breadcrumb-item">
                    <a href="../../<?php echo e($spot->unite->ders->url); ?>"><?php echo e($spot->unite->ders->name); ?></a>
                        </li>
                        <li class="breadcrumb-item">
                                <a href="../<?php echo e($spot->unite->url); ?>"><?php echo e($spot->unite->name); ?></a>
                                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e(ilkHarfBuyuk(showKarakter($spot->icerik,15))); ?>

                    </li>
                </ol>
            </nav>
            <!-- //breadcrumbs -->
        </div>

<div class="container pt-3">
    <div class="row py-sm-5">
        <!-- left grid -->
        <div class="col-lg-8">
            <div class="row">




                <!--    buraya spotun resmi gelecek mümkünse resim 500 olsun        -->




                <div class="masonry col-md-3 ">
                        <div class="brick">
                  
                       
                      
                        <?php $__currentLoopData = $spot->resimler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($loop->index==0): ?>
                          
                          <a href="<?php echo e(asset('storage/assets').'/'.$resim->url); ?>" class="js-img-viwer" data-caption="<?php echo e($spot->icerik); ?>" data-id="raion">
                            <img class="spotImage" src="<?php echo e(asset('storage/assets').'/'.$resim->url); ?>" />
                            </a>
                        <?php else: ?>
                        <a style="display: none" href="<?php echo e(asset('storage/assets').'/'.$resim->url); ?>" class="js-img-viwer" data-caption="<?php echo e($spot->icerik); ?>" data-id="raion">
                            <img style="width: 100%" src="<?php echo e(asset('storage/assets').'/'.$resim->url); ?>" />
                            </a>

                         <?php endif; ?> 
                        
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                       
                                
                    </div>


                </div>



                <div class="inner_banner layer <?php if($spot->resimler->first()): ?> col-md-9    <?php else: ?>  col-md-12    <?php endif; ?>" id="home">
                    <div class="container">
                        <div class="agileinfo-inner">
                            <div id="spot_icerik" style=" white-space: nowrap; overflow: hidden; font-size: 40px;" class="  text-white">
                                     <?php echo e(ilkHarfBuyuk($spot->icerik)); ?>


                                    
                                
                            </div>
                            <div class="row justify-content-center">

                                <div style="display: inherit;" class="text-white justify-content-center spot-bilgi">
                                    <div>
                                        <span style="height: 25px;line-height: 19px;" class="badge badge-light">
                                            </i><?php echo e(getAgo($spot->eklenme_tarihi)); ?> eklendi.</span>
                                    </div>
                                    <div>
                                       
                                        <span class="badge badge-pill badge-info"> <i class="far fa-eye"></i><?php echo e($spot->hit); ?></span>
                                       
                                    </div>

                                    <div>
                                       
                                        <span class="badge badge-pill badge-danger"><i class="far fa-thumbs-up"></i> <?php echo e($spot->like); ?></span>
                                        
                                    </div>

                                    <?php if(Auth::check()&& !userLikeSpot($spot)): ?>
                                        
                                    
                                   
                                    <div class="justify-content-center">
                                            <a href="" class="badge badge-danger spotBegen" style="height: 25px;line-height: 19px;"  > Beğen</a>
                                            <form class="spotBegen" style="display: none;" action='/spotBegen' method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="spotId" value="<?php echo e($spot->id); ?>">
                                            
                                            </form>
                                    </div>
                                    <?php endif; ?>

                                </div>
                                <style>
                                </style>

                            </div>
                        </div>
                    </div>
                </div>
                <div style="margin: auto;margin-top: 10px">
                   
                            <?php echo e($paginateSpotlar->links()); ?>


                   
                        

                </div>

               

                <div class="container">
                    <div class="all-comments mt-5">
                        <div class="wthree-form-left">
                            <!-- contact form grid -->
                           


                            <?php echo $__env->make('yorum-kisim.yorumlar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                               

                            
                            <!--  //contact form grid ends here -->
                        </div>

                    </div>
                </div>














            </div>
        </div>
        <!-- //left grid -->
        <!-- right grid -->
        <div class="col-lg-4 sidebar_wthree">
            <!-- Search Widget -->
            <div class="card mb-4">
                <div class="card-body">

                    <form id="searchForm" class="input-group" method="post" action="/spotSearch">
                        <?php echo csrf_field(); ?>
                        <input id="search-text" name="searchText" type="text" class="form-control" placeholder="Spot Ara">
                        <span class="input-group-btn">
                            <button value="searchSpot" name="searchSpot" class="btn btn-secondary" type="submit">Ara!</button>
                        </span>


                    </form>






                </div>
                </div>

                <!-- arama sonucunda açılacak -->
            <!-- latest post -->
            <div style="display: none;" id="search-result" class="row">
                    
                    <div  class="card my-4 p-3 post_link col-md-12">
                            <h5 class=" card-header"><span id="aranan-kelime" class="badge badge-info"></span><span> için sonuçlar</span> </h5>
                        <div id="result">


                        </div>
    
    
                        <!--     konunun limki buraya koyulacak        -->
    
                      
                        <!--     konunun limki buraya koyulacak        -->
    
                    </div>
    
    
    
                </div>
    
                <!-- arama sonucunda açılacak yer -->
            <!-- Categories Widget -->
            <div class="card my-4">
                <h5 class="card-header">Konular</h5>
                <div class="card-body">
                    <ul class="w3-tag2">
                        
                        <?php $__currentLoopData = $uniteler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>


                                <!-- konuları buradan tekrar ettirirsin -->
                                <a href="../<?php echo e($unite->url); ?>">
                                    <i class="fa fa-angle-right mr-2"></i><?php echo e($unite->name); ?></a>
    
    
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                    </ul>
                </div>
            </div>

            <!-- latest post -->
           <?php echo $__env->make('components.spot-bilgiler', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- //right grid -->
    </div>
</div>
<!-- //blog -->
</div>
<?php $__env->stopSection(); ?>


<!-- icerik section sonu -->



<?php $__env->startSection('js'); ?>



<script src="<?php echo e(asset('js/smartphoto.js?v=1')); ?>"></script>
<script>
    document.addEventListener('DOMContentLoaded',function(){
		new SmartPhoto(".js-img-viwer",{
            resizeStyle:'fit'
        });
	});
</script>

<script>

   var bastaBeklemeSuresi = 2000;
   var harfKaymaSuresi = 200;
   var birTurBeklemeSuresi = 1000;

   
// function (){
                       
             
            
//              ilkHarf = icerik.substr(0,1);
//             //  console.log(ilkHarf);
//              geriKalan = icerik.substr(1,icerik.lenght);
//              icerik = geriKalan + ilkHarf;
//             //  console.log(kaymisYazi);
//             $('#spot_icerik').html(icerik);

// }



     
        
    
        // $("#spot_icerik").animate({width:'0'},1);
        $(function(){
            // console.log();
            var icerik=$("#spot_icerik").html().trim();
           
            var icerikCopy = icerik;
            icerikLenght = icerik.length-1;
            var acik = true;
              var i = 0;
              var interval;
            
            function kayanYazi (){
               
                
                
              
                interval = window.setInterval(function(){
                if(acik){
                if(i==icerikLenght){
                clearInterval(interval);
                i = 0;
                icerik = icerikCopy;
                $("#spot_icerik").html(icerik);
                setTimeout(kayanYazi,birTurBeklemeSuresi);
                
                }
                $("#spot_icerik").html(icerik);
                icerik = icerik.substr(1,icerik.lenght);
               
                // console.log(icerik);
                console.log(i);
                i++;

                }},harfKaymaSuresi);
};

                setTimeout(kayanYazi,bastaBeklemeSuresi);
                                

                $('#spot_icerik').click(function(){


                    acik=!acik;
                });




                // $("#spot_icerik").on('hover touchstart', function() {

                //      acik=false;
                // });

                

                //     $("#spot_icerik").on('mouseout touchend', function(event) {
                //         acik=true;
                //     });
                    
 

               


            // burada en son kayan yazı için zamanlama yapıyodun onu ayarlarsın kayan yazı için 
            // kayan yazıyı düzelt düzelt düzgün olsun onun dışında diğerlerini düzgün yaptın yzaten
            
           
            
            
            // for(var i = 0; i<=icerikLenght;i++){
               
            //     var timeOut = setTimeout(function(){
            //         icerik = icerik.substr(1,icerik.lenght);
            //         $("#spot_icerik").html(icerik);

            //     },200);

            // }
            // $('#spot_icerik').animate({"margin-right": '+=200'});
            

            //   $('#spot_icerik').show("slide", { direction: "left" }, 1000);

        //     icerik = $('#spot_icerik').html().trim();
        //     icerik+='      ';
        //     var dongu = setInterval(,250);
            
           
        //        $('.cevaplaButton').on( "click", function(e) { 
        //        e.preventDefault();
        //        $($(this)).next().slideToggle();
        //     //    console.log( 'text' ); 
               
               
        //        }); 
               
               
               
               });
             
              
                                      
    </script>

        <script>



    var searchTime = 700;

    //aramayla ilgili fonksiyonlar işlemler burada yapılıyor
        $(function(){

            var form = $('#searchForm').submit(function(e){
                    
                e.preventDefault();


                });
               
              
        $('#search-text').on('input',function(e){
          var girilenYazi = $(this).val();
           
            if(girilenYazi==''){
                $('#search-result').slideUp(searchTime);
            }
            else{
                $('#search-result').slideDown(searchTime);
                        $('#aranan-kelime').html(girilenYazi);
                
                // burada jquery post atacan gelenle işlem yapacan
                $.ajax({
                    type: "POST",
                    url: form.attr('action'),
                    data: form.serialize(),
                    success: function(data){
                        var result = $('#result');
                       
                           
                           
                        
                       
                        var text = '';
                        
                        data = JSON.parse(data);
                        // console.log(typeof data !== 'undefined' && data.length > 0);
                        if(typeof data !== 'undefined' && data.length > 0){
                            // console.log('boş');
                            Object.keys(data).forEach(function(spot , index) {

                                text += '<div class="row mt-3">'+
                                            '<div class="forum-home-parent col-12 pl-0">'+
                                                    '<div class="forum-home col-md-12">'+
                                                        '<a href="'+data[spot]["url"] +'">'+ data[spot]["icerik"]  +'</a>'+
                                                        '</div> </div> <div class="hr"></div></div>';

    
                                 console.log(data[spot]['icerik']);
                          });
                          
                        }
                        else{
                            text='<span class="text-justify badge badge-danger">'+girilenYazi + ' için sonuç bulunamadı...'+'</span>';
                        }
                        

                        
                       
                        
                          result.html(text);
                        
                        },



                        
                        
                    error: function (xhr, ajaxOptions, thrownError) { 
                       
                        }
                    
                   
                    });

              
            }
           
    
    });
    
    
    
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>