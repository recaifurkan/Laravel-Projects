 
<?php $__env->startSection('language'); ?>
<html lang="tr">
<?php $__env->stopSection(); ?>






<!--  başlık belirtilecek  -->


<?php $__env->startSection('title'); ?>
<title><?php echo e(ilkHarfBuyuk($haber->baslik)); ?> : Haberler</title>
<?php $__env->stopSection(); ?>



<!-- keywordlar belirtilecek -->


<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="<?php echo e($haber->keywords); ?>" />
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>





<div class="container">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/haber">Haberler</a>
                    </li>
                    <li class="breadcrumb-item">
                    <a href="/haber/<?php echo e(trim($haber->kategori->url)); ?>"><?php echo e(ilkHarfBuyuk($haber->kategori->name)); ?></a>
                        </li>
                   
                    <li class="breadcrumb-item active " aria-current="page">
                   <?php echo e(ilkHarfBuyuk($haber->baslik)); ?>

                                </li>
                   
                   
                    
                      
                   
                </ol>
            </nav>
            <!-- //breadcrumbs -->
        </div>
<!--  single page -->
<section class="single_blog_wthree py-3">
    <div class="container pt-lg-5">
        <div class="row py-sm-3">
            <!-- single page left grid -->
            <div class="col-lg-9  single-left">
                <div class="row show-top-grids">
                    <div style="width: 90%" class="card">
                        <h5 class="blog-title singlpage_w3 card-title font-weight-bold">
                        <?php echo e(ilkHarfBuyuk($haber->baslik)); ?>

                        </h5>
                       
                      
                        <div class="card-body">
                            <div class="d-sm-flex justify-content-between border-bottom pb-3">
                                    <div class="blog_w3icon">
                                            <span>
                                            <i class="fas fa-user mr-2"></i><?php echo e(ilkHarfBuyuk($haber->user->name)); ?></span>
                                            <span class="ml-sm-3 ml-2">
                                                <span class="card-text col-sm-3"><i class="far fa-eye"><?php echo e($haber->hit); ?></i></span>
                                        </div> 
                            </div>
                            <article class="mt-3"><?php echo htmlspecialchars_decode($haber->icerik); ?></article>
                           
                        </div>
                       
                        <div class="card-footer">
                            <p class="card-text">
                                <small class="text-muted"><?php echo e(getAgo($haber->eklenme_tarihi)); ?></small>
                            </p>
                        </div>
                      
                    </div>
                   
                    <div style="width: 100%;margin-top: 20px;">
                            <?php echo $__env->make('haberler-yorum.yorumlar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    </div>
                        
                      
                        
                    
                </div>
            </div>
            <!-- //single page right grid -->
            <?php echo $__env->make('components.haberlerSlider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</section>
<!-- //single blog -->
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>