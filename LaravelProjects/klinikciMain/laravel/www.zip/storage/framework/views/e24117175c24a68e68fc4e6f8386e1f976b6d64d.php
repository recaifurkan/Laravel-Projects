<?php
if(session()->get('hatalar')){
 $hatalar = session()->get('hatalar');
}

if(session()->get('succes')){
 $succes = session()->get('succes');
}
    
?>
  <?php if(isset($hatalar)): ?>
<div class="alert-danger" >                 
  <?php $__currentLoopData = $hatalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php echo e($error); ?>  <br>                 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>




<?php if(isset($succes)): ?>

<div class="alert-success" >
    <?php echo e($succes); ?> 
 </div>


  <?php endif; ?>