<?php $__currentLoopData = $konular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                   
                  <div class="row ">
                   
                    <div class="col-md-6 text-center ">
                        <a href="forum/<?php echo e($konu->kategori->url); ?>/<?php echo e($konu->url); ?>"><?php echo e($konu->aciklama); ?></a>
                
                    </div>
                    <div class="forum-bilgi col-md-6 text-muted">
                            <span ><i class="fas fa-comments"><?php echo e($konu->mesajlar->count()); ?></i></span>
                            <span class="card-text"> <?php echo e(getAgo($konu->acilis_tarihi)); ?></span>
                            <span><i class="far fa-eye"><?php echo e($konu->goruntulenme_sayisi); ?></i></span>
                            
                            <span class="badge badge-pill badge-danger"><i class="far fa-thumbs-up"></i> <?php echo e($konu->begenilme_sayisi); ?></span>
                        </div>
                
                
                
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   