<?php $__env->startSection('css'); ?>
    <!-- DATA TABLES -->
    <link href="/admin/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Konular
        
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>İd</th>
                    <th>İsim</th>
                    <th>Url</th>
                    <th>Anahtar Kelimeler</th>
                    <th>Aktiflik</th>
                    <th>Açılış Tarihi</th>
                    <th>Açıklama</th>
                    <th>Kategorisi</th>
                    <th>Görüntülenme Sayısı</th>
                    <th>Beğenilme Sayısı</th>
                    <th>Konuyu Açan</th>
                    <th>İşlemler</th>
                    
                  </tr>
                </thead>
                <tbody>

                  <?php $__currentLoopData = $konular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                
                  <tr>
                    <td><?php echo e($konu->id); ?></td>
                    <td><?php echo htmlspecialchars_decode(showKarakter($konu->name,10)); ?></td>
                    <td><?php echo e($konu->url); ?></td>
                    <td><?php echo e(showKarakter($konu->keywords,10)); ?></td>
                    <td><?php echo e($konu->isaktif); ?></td>
                    <td><?php echo e($konu->acilis_tarihi); ?></td>
                    <td><?php echo htmlspecialchars_decode(showKarakter($konu->aciklama,10)); ?></td>
                    <td><?php echo e($konu->kategori->name); ?></td>
                    <td><?php echo e($konu->goruntulenme_sayisi); ?></td>
                    <td><?php echo e($konu->begenilme_sayisi); ?></td>
                    <td><?php echo e($konu->user->name); ?></th>
                      <td>
                        <form action="/admin/forum/deleteKonu" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="konuId" value="<?php echo e($konu->id); ?>">
                        <input type="submit" class="btn btn-danger" name="deleteKonu" value="Sil">
                        
                        </form>
                      <a class="btn btn-success" href="/admin/forum/konuMesajlar/<?php echo e($konu->id); ?>">Mesajları Gör</a>
                        </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tbody>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <script type="text/javascript">
    
        $(function () {
        
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
   
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>