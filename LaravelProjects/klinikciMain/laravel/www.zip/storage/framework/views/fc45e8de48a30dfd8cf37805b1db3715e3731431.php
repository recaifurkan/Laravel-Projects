<?php $__env->startSection('css'); ?>
    <!-- DATA TABLES -->
    <link href="/admin/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <section class="content-header">
            <div class="row">
              <div class="col-md-8">
                  <h1>
                      Kategori Dersleri : <?php echo e($kategori->name); ?>

                      
                    </h1>
              </div>
              <div class="col-md-4">
              <h1><a class="btn btn-success align-middle" href="/admin/spot/addDers/<?php echo e($kategori->id); ?>">Ders Ekle</a></h1>
                
              </div>
      
            </div>
           
          
          </section>
      <h1>
      
        
      </h1>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">

               <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 


              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>İd</th>
                    <th>İsim</th>
                    <th>Açıklama</th>
                    <th>Url</th>
                    <th>Kategorisi</th>
                    <th>İşlemler</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $dersler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                 
                  <tr>
                      <td><?php echo e($ders->id); ?></td>
                      <td><?php echo e($ders->name); ?></td>
                      <td><?php echo e($ders->aciklama); ?></td>
                      <td><?php echo e($ders->url); ?></td>
                      <td><?php echo e($ders->kategori->name); ?></td>
                      <td>
                          <a class="btn btn-info" href="/admin/spot/editDers/<?php echo e($ders->id); ?>">Düzenle</a>
                          <form method="POST" action="/admin/spot/deleteDers">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="dersId" value="<?php echo e($ders->id); ?>">
                            <input class="btn btn-danger" type="submit" value="Sil">
                        
                        </form>
                          <a class="btn btn-warning" href="<?php echo e(route('admin-spot-uniteler',['dersId'=>$ders->id])); ?>">Üniteleri Gör</a>
                       
                        </td> 
                   
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tfoot>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>