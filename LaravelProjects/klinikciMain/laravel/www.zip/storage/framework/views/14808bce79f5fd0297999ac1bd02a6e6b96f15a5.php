<?php $__env->startSection('icerik'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="row">
            <div class="col-md-8">
                <h1>
                    Slaytlar
                    
                  </h1>
            </div>
            <div class="col-md-4">
            <h1><a class="btn btn-success align-middle" href="<?php echo e(route('addSlayt')); ?>">Slayt Ekle</a></h1>
              
            </div>
    
          </div>
    
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
           
            <div class="box-body">
              <?php echo $__env->make('admin.showErrorsSucces', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    
                   
                    <th>Sıra</th>
                    <th>Aktif</th>
                    <th>Resim</th>
                    <th>işlemler</th>
                 
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $slaytlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slayt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                
                  <tr>
                    
                    
                    <td><?php echo e($slayt->sira); ?> </td>
                    <td><?php echo e($slayt->isaktif); ?> </td>
                     <td>
                       
                        <img style="width: 100px;height: 50px" src="<?php echo e(asset('storage/assets').'/'.$slayt->resim->url); ?>" />
                       
                     </td>
                      <td>
                      <a class="btn btn-info" href="/admin/slayt/editSlayt/<?php echo e($slayt->id); ?>">Düzenle</a>
                        <form action="/admin/slayt/deleteSlayt" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="slaytId" value="<?php echo e($slayt->id); ?>">
                        <input type="submit" value="Sil" class="btn btn-danger">
                      </form>
                      </td>
                  </form>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tfoot>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

          
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function () {
          $("#example1").dataTable();
          $('#example2').dataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bFilter": false,
            "bSort": true,
            "bInfo": true,
            "bAutoWidth": false
          });
        });
      </script>
          <!-- DATA TABES SCRIPT -->
    <script src="/admin/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="/admin/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>
   


    

<?php echo $__env->make('/admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>