 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<title><?php echo htmlspecialchars_decode(ilkHarfBuyuk($konu->name)); ?></title>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>
<meta name="keywords" content="<?php echo htmlspecialchars_decode($konu->keywords); ?>" />
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>
<div class="container">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                     <li class="breadcrumb-item" aria-current="page">
                  <a href="/forum">Forum</a>
                     </li>
                     <li class="breadcrumb-item  " aria-current="page">
                     <a href="/forum/<?php echo e(trim($konu->kategori->url)); ?>"><?php echo e(ilkHarfBuyuk($konu->kategori->name)); ?></a>
                    </li>
                    <li class="breadcrumb-item active " aria-current="page">
                           <?php echo e(ilkHarfBuyuk($konu->name)); ?>

                           </li>
                   
                   
                    
                      
                   
                </ol>
            </nav>
            <!-- //breadcrumbs -->
        </div>

<?php echo $__env->make('konuyaMesajEkle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="container pt-lg-5">
    <div class="row py-lg-5">

        <!-- konu açılış mesajı       -->
      
        <!-- blog grid -->
        <div class="card categorys">
                <div  class="badge badge-pill badge-danger">Konu Açılış Mesajı</div>
            <div class="row no-gutters">
                <div class="col-md-3" style="margin: auto">

                    <div style="text-align: center" class="col-md-12">
                       <?php if(isset($konu->user)): ?>
                           
                      
                        <div>
                            
                                    <img width="50%" class="text-center" src="<?php echo e(route('profilResim',['uyeId'=>$konu->user->id])); ?>" alt="<?php echo e(isset($konu->user->name) ? $konu->user->name: $konu->user->kullanici_adi); ?>">
                            


                       </div>
                       
                        <span class="badge badge-pill badge-secondary"><?php echo e(isset($konu->user->kullanici_adi)==1 ?$konu->user->kullanici_adi:$konu->user->name); ?></span>
                        
                    
                        <br>
                        <span class="badge badge-pill badge-info">Konu Sahibi
                            <i class="fas fa-check-double"></i>
                        </span>
                        <br>
                        <?php
                                $mesajSayisi = $konu->user->formKonuMesajlar->count() + $konu->user->formKonular->count();
                            ?>
                        <span>Toplam</span>
                        <span class="badge badge-pill badge-info"> <?php echo e($mesajSayisi); ?></span>
                        <span>mesaj</span>
                        <?php else: ?>
                        Konu sahibi Şu anda Bulunamıyor
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-9">
                    <div style="height:90%" class="card-body">
                        <div class=" text-center ">

                                <span>
                                    <i class="far fa-comments"></i><?php echo e($konu->mesajlar->count()); ?></span>
                                <span >
                                    <i class="far fa-eye"></i><?php echo e($konu->goruntulenme_sayisi); ?></span>
                                   
                                    <span ><i class="fas fa-comments"><?php echo e($konu->mesajlar->count()); ?></i></span>
                                   
                                        <?php if(Auth::check()&& !userLikeKonu($konu)): ?> 
                                    <a href="" class="badge-pill badge-warning text-center konuBegen"><i style="color: white" class="far fa-thumbs-up"></i> <?php echo e($konu->begenilme_sayisi); ?></a>
                                   
                                   
                                    <form class="konuBegen" style="display: none;" action='/konuBegen' method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="konuId" value="<?php echo e($konu->id); ?>">
                                    
                                    </form>
                                    <?php else: ?>

                                    <a  class="badge-pill badge-info  text-center"><i style="color: red" class="far fa-thumbs-up"></i> <?php echo e($konu->begenilme_sayisi); ?></a>


                                    <?php endif; ?>

                                   
                           
                        </div>
                        
                        <div style="padding-top:2px;padding-bottom: 0px;height: 100%" class="jumbotron">
                                <h3 ><?php echo htmlspecialchars_decode(trim($konu->name)); ?></h3>
                                <hr style="margin:0px;">

                                <p style="margin-top:5px;" ><?php echo htmlspecialchars_decode($konu->aciklama); ?></p>
                                <small style="margin-right: 0px;margin-bottom: 0px;"  class="text-muted">
                                        <span >
                                                <i class="far fa-calendar-alt"></i><?php echo e(getAgo($konu->acilis_tarihi)); ?></span>
                                        </small>
                        </div>
                       

                        
                    </div>
                </div>
            </div>
        </div>
        <!-- //blog grid -->
        <!-- konu açılış mesajı       -->

    </div>


</div>
<hr>
<!--     burada da diğüer mesajlar listelenecek        -->
<div class="container pt-lg-5">
    <div class="row py-lg-5">
        <?php
            $mesajlar = $konu->mesajlar()->paginate(6);


        ?>

        <?php $__currentLoopData = $mesajlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesaj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        

        <!-- konu içindeki diğer mesajlar      -->
            <!-- blog grid -->
            <div class="card categorys">
                <div class="row no-gutters">
                    <div class="col-md-3">

                        <div style="text-align: center" class="col-md-12">
                           <div>
                                <a href="single.html">
                                        <img width="50%" class="text-center" src="<?php echo e(route('profilResim',['uyeId'=>$mesaj->user->id])); ?>" 
                                        alt="<?php echo e(isset($mesaj->user->name) ? $mesaj->user->name: $mesaj->user->kullanici_adi); ?>">
                                </a>


                           </div>
                            
                            <span class="badge badge-pill badge-secondary"><?php echo e($mesaj->user->name); ?></span>

                            <?php if($konu->user->id == $mesaj->user->id): ?>
                            <br>
                            <span class="badge badge-pill badge-info">Konu Sahibi
                                <i class="fas fa-check-double"></i>
                            </span>
                            <?php endif; ?>
                            
                            <br>
                            <?php
                                $mesajSayisi = $mesaj->user->formKonuMesajlar->count() + $mesaj->user->formKonular->count();
                            ?>
                            <span>Toplam</span>
                            <span class="badge badge-pill badge-info"><?php echo e($mesajSayisi); ?></span>
                            <span>mesaj</span>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="card-body">
                            <div class="d-sm-flex justify-content-between border-bottom py-2">

                                <div class="blog_w3icon">
                                 <small class="text-muted"> <span class="ml-3">
                                                <i class="far fa-calendar-alt"></i><?php echo e(getAgo($mesaj->yazilma_tarihi)); ?> </span></small>
                                                <?php if(Auth::check()&& !userLikeKonu($mesaj)): ?> 
                                                <a href="" class="badge-pill badge-warning text-center konuMesajBegen"><i style="color: white" class="far fa-thumbs-up"></i> <?php echo e($mesaj->begeni); ?></a>
                                               
                                               
                                                <form class="konuMesajBegen" style="display: none;" action='/konuMesajBegen' method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="mesajId" value="<?php echo e($mesaj->id); ?>">
                                                
                                                </form>
                                                <?php else: ?>
            
                                                <a  class="badge-pill badge-info  text-center"><i style="color: red" class="far fa-thumbs-up"></i> <?php echo e($konu->begenilme_sayisi); ?></a>
            
            
                                                <?php endif; ?>


                                </div>
                            </div>
                            <div style="padding-top:2px;padding-bottom: 0px;height: 100%" class="jumbotron">
                                 
                                   
    
                                    <p style="margin-top:5px;" ><?php echo htmlspecialchars_decode($mesaj->icerik); ?></p>
                                    <small style="margin-right: 0px;margin-bottom: 0px;"  class="text-muted">
                                            <span >
                                                    <i class="far fa-calendar-alt"></i><?php echo e(getAgo($mesaj->yazilma_tarihi)); ?></span>
                                            </small>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- //blog grid -->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <!--konu içindeki diğer mesajlar      -->

        <div style="margin: auto; margin-top: 10px;"><?php echo e($mesajlar->links()); ?></div>



    </div>



</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>

<?php if(Auth::check()): ?>
<script>
        // burada beğeni tuşu ayarlaması yapıldı
                    $(function(){
    
                $('.konuMesajBegen').click(function(e){
                    e.preventDefault();
                    var form = $(this).next();
                    
                    // console.log(form);
                    
    
                $.ajax({
                type: "POST",
                url: form.attr('action'),
                data: form.serialize() ,
                success: function (data){
                    
                    // console.log(data);
                    location.reload();
                },
    
                });
    
    
                });
    
    
                });
    
    // burada beğeni tuşu ayarlaması yapıldı
        </script>
<?php endif; ?>

<?php if(Auth::check()&& !userLikeKonu($konu)): ?>
                                     
                                        <script>
                                                // burada beğeni tuşu ayarlaması yapıldı
                                                            $(function(){
                                            
                                                        $('.konuBegen').click(function(e){
                                                            e.preventDefault();
                                                            var form = $(this).next();
                                                            
                                                            // console.log(form);
                                                            
                                            
                                                        $.ajax({
                                                        type: "POST",
                                                        url: form.attr('action'),
                                                        data: form.serialize() ,
                                                        success: function (data){
                                                            
                                                            // console.log(data);
                                                            location.reload();
                                                        },
                                            
                                                        });
                                            
                                            
                                                        });
                                            
                                            
                                                        });
                                            
                                            // burada beğeni tuşu ayarlaması yapıldı
                                                </script>

                                                <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>