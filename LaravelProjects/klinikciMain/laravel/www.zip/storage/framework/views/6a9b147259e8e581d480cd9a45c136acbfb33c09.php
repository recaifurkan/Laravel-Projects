 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>


<div class="container pt-lg-5">
    <div class="row py-lg-5">

        <!-- konu açılış mesajı       -->

        <!-- blog grid -->
        <div class="card categorys">
            <div class="row no-gutters">
                <div class="col-md-3">

                    <div style="text-align: center" class="col-md-12">
                        <a href="single.html">
                            <img class="card-img-bottom" src="images/img4.jpg" alt="Card image cap">
                        </a>
                        <span class="badge badge-pill badge-secondary">Recai Furkan Bostancı</span>
                        <br>
                        <span class="badge badge-pill badge-info">Mesaj Sahibi
                            <i class="fas fa-check-double"></i>
                        </span>
                        <br>
                        <span class="badge badge-pill badge-info">12</span>
                        <span>mesaj</span>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="card-body">
                        <div class="d-sm-flex justify-content-between border-bottom py-2">

                            <div class="blog_w3icon">

                                <span>
                                    <i class="far fa-comments"></i>25</span>
                                <span>
                                    <i class="far fa-eye"></i>15</span>
                                <span class="ml-3">
                                    <i class="far fa-calendar-alt"></i>12 Ağustos 2018 </span>
                                <button class="badge badge-pill badge-warning">
                                    <span>
                                        <i class="fas fa-thumbs-down"></i>20</span>
                                </button>

                                <button class="badge badge-pill badge-warning">
                                    <span>
                                        <i class="far fa-thumbs-up"></i>20</span>
                                    </button>


                            </div>
                        </div>
                        <p class="card-text mt-3">Cras ultricies ligula sed magna dictum porta. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar
                            a. Pellentesque in ipsum id orci porta sed magna dictum dapibus.</p>

                        <p class="card-text">
                            <small class="text-muted">Last updated 3 mins ago</small>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- //blog grid -->
        <!-- konu açılış mesajı       -->

    </div>


</div>

<!--     burada da diğüer mesajlar listelenecek        -->
<div class="container pt-lg-5">
    <div class="row py-lg-5">

        <!-- konu içindeki diğer mesajlar      -->
<!-- blog grid -->
<div class="card categorys">
    <div class="row no-gutters">
        <div class="col-md-3">

            <div style="text-align: center" class="col-md-12">
                <a href="single.html">
                    <img class="card-img-bottom" src="images/img4.jpg" alt="Card image cap">
                </a>
                <span class="badge badge-pill badge-secondary">Recai Furkan Bostancı</span>
                <br>
                <span class="badge badge-pill badge-info">Mesaj Sahibi
                    <i class="fas fa-check-double"></i>
                </span>
                <br>
                <span class="badge badge-pill badge-info">12</span>
                <span>mesaj</span>
            </div>
        </div>
        <div class="col-md-9">
            <div class="card-body">
                <div class="d-sm-flex justify-content-between border-bottom py-2">

                    <div class="blog_w3icon">

                        <span>
                            <i class="far fa-comments"></i>25</span>
                        <span>
                            <i class="far fa-eye"></i>15</span>
                        <span class="ml-3">
                            <i class="far fa-calendar-alt"></i>12 Ağustos 2018 </span>
                        <button class="badge badge-pill badge-warning">
                            <span>
                                <i class="fas fa-thumbs-down"></i>20</span>
                        </button>

                        <button class="badge badge-pill badge-warning">
                            <span>
                                <i class="far fa-thumbs-up"></i>20</span>
                            </button>


                    </div>
                </div>
                <p class="card-text mt-3">Cras ultricies ligula sed magna dictum porta. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar
                    a. Pellentesque in ipsum id orci porta sed magna dictum dapibus.</p>

                <p class="card-text">
                    <small class="text-muted">Last updated 3 mins ago</small>
                </p>
            </div>
        </div>
    </div>
</div>
<!-- //blog grid -->
        
        <!--konu içindeki diğer mesajlar      -->





    </div>



</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>