 
<?php $__env->startSection('language'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('keywords'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('icerik'); ?>











<div style="position: fixed; z-index: 999">
    <button id="loginButton" type="button" class="btn btn-danger ml-lg-5 w3ls-btn" data-toggle="modal" aria-pressed="false" data-target="#forumKonu">
        <img style="width: 40px;height: 40px" src="images/f2.png" alt="" class="img-fluid">
    </button>
</div>


    
 
<div class="modal fade" id="forumKonu" tabindex="-100" role="dialog" aria-labelledby="exampleModalLabe2" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Login</h5>
    <button id="kapamaButton" type="button" class="close" data-dismiss="modal" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <div class="modal-body">
        <?php if(!Auth::check()): ?>

        <div style="text-align: center; z-index: 10;">
            <p>Cevap verebilmek için lütfen giriş yapınız...</p>

            <button onclick="$('#kapamaButton').click()" id="loginButton" type="button" class="btn btn-danger ml-lg-5 w3ls-btn" data-toggle="modal" aria-pressed="false" data-target="#exampleModel">
                    Giriş Yap
                </button>
        </div>


        <?php else: ?>
       
       
        
    
    
    
        <form method="POST" id="loginForm" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
            <?php echo csrf_field(); ?>
            <div   id="messagesLogin"></div>
    <div class="form-group">
           
        <label for="email" class="col-sm-4 col-form-label text-md-right">E-mailiniz</label>
        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
    </div>
    <div class="form-group">
            <label for="password" class="col-md-4 col-form-label text-md-right">Şifreniz</label>
            <input id="password" type="password" class="form-control" name="password" required>
    
            
    </div>
    <div class="col text-center sub-agile">
            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
    
            <label class="form-check-label" for="remember">
                Beni hatırla
            </label>
    </div>
    <div style="margin-top: 15px;" class="right-w3l">
        <input type="submit" class="form-control border text-white" value="Giriş yap">
    </div>
    <div class="row sub-w3l col-md-12">
        
        <div class=" text-center  col-md-12  text-dark">
                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                       Şifreni hatırlamıyor musun?
                    </a>
                </div>
            </div>
    
                    <script>
            
            $('#loginForm').submit(function(e){
    
                console.log('tiklandi');
                e.preventDefault();
                $.ajax({
                    type: $(this).attr('method'), 
                    url:  $(this).attr('action'), 
                    data: $(this).serialize(), 
                    success: function(data){
                        location.reload();
                        // console.log(data);
                        
                        },
                    error: function (xhr, ajaxOptions, thrownError) { 
                        $response = JSON.parse(xhr.responseText);
                        $errors = $response.errors;
                        $errorEmail = $errors.email;
                        text = '';
                        Object.keys($errors).forEach(function(error , index) {
                            Object.keys($errors[error]).forEach(function(value , index) {
                           
                           text += $errors[error][value] + '<br>';
                           // console.log($errors[error][value]);
    
    
                       });
                            
                            
                           
                        })
    
                         $('#messagesLogin').html(text).addClass('alert alert-danger');
    
                        // console.log(text);
                        // console.log($response.message);
                        //  console.log(thrownError);
                            
                        }
                     
                });
            
            });
                    
                    
                    
                    
                    </script>
       
    <p class="text-center">Hesabınız Yok mu?
        <a href="#" data-toggle="modal" data-target="#exampleModal1" class="text-dark font-weight-bold">
            Hesap oluştur</a>
    </p>
    </form>

    <?php endif; ?>

    </div>
    </div>
    </div>
    </div>
    
    
    
    
    
    
    



    




<div class="container" style="text-align: center">
    <?php echo $__env->make('components.forumKonuArama', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
   
    <section>
        

            <!-- arama sonucunda açılacak yer -->

            <?php $__currentLoopData = $kategoriler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- latest post -->
            <div class="row">
               <div class="card my-4 p-3 post_link col-md-12 ">
               <a href="forum/<?php echo e($kategori->url); ?>"><h5 class="card-header"><?php echo e($kategori->name); ?></h5></a>


                   <!--     konunun limki buraya koyulacak        -->

                  
                  
                   <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $konular = $kategori->konular()->paginate(15,['*'],$kategori->url)], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
                 
                   <div style="margin: auto;margin-top: 10px"><?php echo e($konular->links()); ?></div> 
                  
                   <!--     konunun limki buraya koyulacak        -->

               </div>

              

           </div>

           <!-- farklı konudaki konuların gösterilmesi gereken yer -->
               
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            <!-- latest post -->
            <div class="row">
                <div class="card my-4 p-3 post_link col-md-12 ">
                    <h5 class="card-header">En Son Tartışılan Konular</h5>


                    <!--     konunun limki buraya koyulacak        -->

                   
                   
                    <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $enSonAcilanKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   
                   
                   
                   
                    <!--     konunun limki buraya koyulacak        -->

                </div>



            </div>

            <!-- farklı konudaki konuların gösterilmesi gereken yer -->

             <!-- latest post -->
             <div class="row">
                <div class="card my-4 p-3 post_link col-md-12 ">
                    <h5 class="card-header">En Hit Alan Konular</h5>


                    <!--     konunun limki buraya koyulacak        -->

                   
                   
                    <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $enHitAlanKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   
                   
                   
                   
                    <!--     konunun limki buraya koyulacak        -->

                </div>



            </div>

            <!-- farklı konudaki konuların gösterilmesi gereken yer -->

             <!-- farklı konudaki konuların gösterilmesi gereken yer -->

             <!-- latest post -->
             <div class="row">
                <div class="card my-4 p-3 post_link col-md-12 ">
                    <h5 class="card-header">En Çok Beğeni Alan Konular</h5>


                    <!--     konunun limki buraya koyulacak        -->

                   
                   
                    <?php echo $__env->make('components.anasayfaForumKonular',['konular'=> $enBegeniAlanKonular], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   
                   
                   
                   
                    <!--     konunun limki buraya koyulacak        -->

                </div>



            </div>

            <!-- farklı konudaki konuların gösterilmesi gereken yer -->

          






       
    </section>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>







<?php $__env->stopSection(); ?>





<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>