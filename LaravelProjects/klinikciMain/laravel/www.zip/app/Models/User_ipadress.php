<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User_ipadress extends Model
{
    //user ip adres kaydı tutulacak daha ayarlamadın ileri doğru bu işe girişirsin
}
