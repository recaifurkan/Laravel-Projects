<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Spot_user extends Model
{
    // bu tablo ile hangi user hangi spotu beğendi belirlenir ve one göre işlemler yapılır
    // eğer önceden beğenmişse bi daha beğenemez onların kayıtları bu tabloda
    // 
}
