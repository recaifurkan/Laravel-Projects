<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Site_Hizmet extends Model
{
    //
}
